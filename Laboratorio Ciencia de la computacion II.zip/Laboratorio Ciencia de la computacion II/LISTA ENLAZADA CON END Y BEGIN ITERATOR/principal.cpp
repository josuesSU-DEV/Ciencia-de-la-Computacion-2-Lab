#include<iostream>
#include<list>
#include<conio.h>
#include "Nodo.h"
#include<memory>
using namespace std;
class Carro{
    private:
        string modelo;
    public:
        Carro(string modelo=" "){
            this->modelo=modelo;
        }
        string getModelo()const{
            return this->modelo;
        }
};
template<typename T>
class List{

};
constexpr factorial(int n){
    if(n==1){
        return 1;
    }
    else{
        return n*factorial(n-1);
    }
}

using namespace std;
int main(){
    cout<<factorial(4);
    /*
    Node<int> prueba(3);
    LinkedList <int>lista;
    lista.insertBegin(2);
    lista.insertBegin(4);
    lista.insertBegin(15);
    lista.insertEnd(7);
    lista.insertEnd(9);
    lista.insertBegin(13);
    lista.insertEnd(100);
    
    LinkedList<int> lista2=lista;
    cout<<lista<<endl;
    cout<<lista<<endl<<endl;
    cout<<"Usando un for para iterar sobre la lista mediante indices"<<endl;
    for (int i=0;i<lista.getLongitud();++i){
        cout<<*lista[i]<<endl;
    }
    cout<<endl<<endl;
    cout<<"Usando un for para iterar sobre la lista mediante direcciones"<<endl;
  
    for (Node<int>*i=lista.begin();i!=nullptr; i=i->getNext()){
        cout<<*i<<endl;
    }
    
    
    cout<<endl<<endl;
    cout<<"Eliminacion del indice 5 de la lista"<<endl;


    

    lista.eliminar(5);
    cout<<"Lista actualizada "<<endl;
    cout<<lista<<endl;
    cout<<"Su nueva longitud seria "<<lista.getLongitud()<<endl;
    
    cout<<"Probando objeto iterador en la lista "<<endl;
    Iterator<int> iterador;
    for(iterador=lista.begin();iterador!=nullptr;iterador++){
        cout<<iterador;
    }
    cout<<"Borramos el primer y ultimo elemento de la lista"<<endl;
    lista.eliminarBegin();
    lista.eliminarEnd();
    cout<<lista<<endl;
    cout<<"La longitud de la lista actualizada es "<<lista.getLongitud()<<endl<<endl;
    list<int>pruebaStl();
    
    cout<<"Antes de invocar al destructor: "<<endl;
    (lista.vacio())?cout<<"La lista esta vacia "<<endl:cout<<"La lista no esta vacia "<<endl<<endl;
    
    lista.~LinkedList();
    cout<<"Despues de invocar al destructor: "<<endl;
    (lista.vacio())?cout<<"La lista esta vacia "<<endl:cout<<"La lista no esta vacia "<<endl;
    */
    int a=15;
    int b=7;
    int c=8;
    shared_ptr<int>pruebaShared;
    shared_ptr<int>pruebaShared2;
    shared_ptr<int>pruebaShared3;
    
    pruebaShared=make_shared<int>(a);
    
    pruebaShared2=make_shared<int>(b);
    pruebaShared3=make_shared<int>(c);
    
    pruebaShared=pruebaShared2;
    pruebaShared2=pruebaShared3;
    pruebaShared2=pruebaShared;
    pruebaShared=pruebaShared3;
    
    cout<<"Primer counter ptr shared "<<pruebaShared.use_count()<<endl;
    cout<<"Segundo counter ptr shared "<<pruebaShared2.use_count()<<endl;
    cout<<"Tercer counter ptr shared "<<pruebaShared3.use_count()<<endl;
    cout<<"--------------------------------------------------------------------------------------------------------------------"<<endl;
    cout<<"Primer valor ptr shared "<<*pruebaShared<<endl;
    cout<<"Segundo  valor ptr shared "<<*pruebaShared2<<endl;
    cout<<"Tercer valor ptr shared "<<*pruebaShared3<<endl;
    shared_ptr<Carro>ptroCarro(new Carro("Hyundai"));
    cout<<ptroCarro->getModelo()<<endl;
    ptroCarro=make_shared <Carro>("Hola");
    cout<<ptroCarro->getModelo()<<endl;
    ptroCarro.~__shared_ptr();

    
    getch();
    return 0;
}
