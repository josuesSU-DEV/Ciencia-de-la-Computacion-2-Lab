#include<iostream>
#include<conio.h>
using namespace std;
class ObjetoNew{
    private:
        int a=3;
        ObjetoNew *ptr;
    public:
        /*ObjetoNew(int _a,ObjetoNew *_ptr=nullptr):ptr(_ptr){
            
            this->a=_a;
        }*/
        ObjetoNew(int _a){
            this->a=_a;
        }
        void write(){
            cout<<this->a;
        }

};
int main(){
    ObjetoNew objeto (7);
    objeto.~ObjetoNew();
    objeto.write();
    getch();
    return 0;
}