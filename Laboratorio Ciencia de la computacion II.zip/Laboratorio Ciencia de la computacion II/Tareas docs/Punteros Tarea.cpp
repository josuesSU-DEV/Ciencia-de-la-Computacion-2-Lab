#include <iostream>
#include<iomanip>
#include<array>
#include<math.h>
#include <ctime>
#include<algorithm>
#include<conio.h>
//Ejercicio 6
using namespace std;
class Notas{
    private:
        int idAlumno;
        float nota;
    public:
        Notas(int _idAlumno,float _nota){
            idAlumno=_idAlumno;
            nota=_nota;
        }
        void setModificarNota(int* _idAlumno){
            float auxNota;
            if(*_idAlumno==idAlumno){
                cout<<"Ingrese la nota ";
                cin>>auxNota;
                nota=auxNota;
            }
            else{
                cout<<"ID incorrecto no se cambiara la nota del alumno"<<endl;
            }
        }
        int getidAlumno(){
            return idAlumno;
        }
        float getMostrarNota(){
            return nota;
        }
};
//void sumaDiez(int *);
//void contarVocales(string *);
int main(){
    int idAlumno,idAlumnoModificacion;
    int* idAlumnoModificacionPtr=&idAlumnoModificacion;
    float nota,notaModificacion;
    cout<<"Ingrese el id del alumno: ";
    cin>>idAlumno;
    cout<<"Ingrese la nota del alumno: ";
    cin>>nota;
    Notas instanciaAlumno(idAlumno,nota);
    cout<<"La nota inicial del alumno con id "<<instanciaAlumno.getidAlumno()<<" es "<<instanciaAlumno.getMostrarNota()<<endl;
    cout<<"Ingrese el id del alumno que quiere modificar la nota: ";
    cin>>idAlumnoModificacion;
    /*cout<<"Ingrese la nota con la que modificara el perfil del alumno: ";
    cin>>notaModificacion;*/
    instanciaAlumno.setModificarNota(idAlumnoModificacionPtr);
    cout<<"La nota del alumno con id "<<instanciaAlumno.getidAlumno()<<" es "<<instanciaAlumno.getMostrarNota()<<endl;
    //string variable;
    //string* PtrVariable=&variable;
    //size_t longitudCadena;
    //cout<<"Ingrese la cadena a contar vocales: ";
    //getline(cin,variable); 
    //cout<<"Ingrese la longitud de la cadena recuerde contar los espacios: ";
    //cin>>longitudCadena;
    
    //contarVocales(PtrVariable);

    /*int a=3;
    int* PtrA=&a;
    cout<<"Valor inicial de la variable con valor 3 es "<<a<<endl;
    sumaDiez(PtrA);
    cout<<"Valor final de la variable con valor 3 es "<<a<<endl;*/
    //system("PAUSE");
    //cout<<"El primer valor es "<<variable[0];
    getch();
    return 0;
}
/*void sumaDiez(int *Ptr){
    *Ptr+=10;
}
void contarVocales(string*cadena){
    size_t a=*cadena.len();
    size_t count=0;
    string varAuxiliar=*cadena;
    for (int i=0;i<a;i++){
        switch (varAuxiliar[i])
        {
        case 'a':
            count+=1;
            break;
        case 'e':
            count+=1;
            break;
        case 'i':
            count+=1;
            break;
        case 'o':
            count+=1;
            break;
        case 'u':
            count+=1;
            break;
        }

    }
    cout<<"La cantidad de vocales de "<<varAuxiliar<<" es "<<count;
}*/