#include <iostream>
#include<iomanip>
#include<array>
#include<math.h>
#include <ctime>
#include<algorithm>
//ejercicio 7 al 11
using namespace std;
const size_t longitud=10;
const size_t longitudArregloUnico=20;
//ejercicio 7
void Asignar450(array<int,longitud> arreglo);
void darBono(array<int,longitud> arreglo);
void mostrarArregloOriginal(array<int,longitud> arreglo);
//ejercicio 8
void darBonoDinamico(array<int,longitud>& arreglo);
void mostrarMayor(const array<int,longitud>arreglo);
void ordenarArregloDinamico(array<int,longitud>& arreglo);
//ejercicio9
void darValores(array<int,longitudArregloUnico>& arreglo);
int main(){
    array<int,longitud>arregloSemiDinamico={};
    //Ejercicio 9
    array<int,longitudArregloUnico>arregloNumerosUnicos={};
    //ejercicio7
    /*Asignar450(arregloSemiDinamico);
    cout<<"Arreglo con Bono"<<endl;
    darBono(arregloSemiDinamico);
    cout<<"Arreglo original"<<endl;
    mostrarArregloOriginal(arregloSemiDinamico);
    //ejercicio 8
    cout<<"Arreglo con Cambio dinamico"<<endl;
    darBonoDinamico(arregloSemiDinamico);
    cout<<"Arreglo ordenado"<<endl;
    ordenarArregloDinamico(arregloSemiDinamico);
    cout<<"Mostrando mayor"<<endl;
    mostrarMayor(arregloSemiDinamico);*/
    //ejercicio 9
    cout<<"Numeros del 10 al 100"<<endl;
    darValores(arregloNumerosUnicos);
    system("PAUSE");
    return 0;
}