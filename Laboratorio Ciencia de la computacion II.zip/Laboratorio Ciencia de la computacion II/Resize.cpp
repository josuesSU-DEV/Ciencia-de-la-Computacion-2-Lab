#include <iostream>
#include "DynamicArray.h"

DynamicArray::DynamicArray()
{
    size = 0;
    arr = new Point[0];
}

DynamicArray::DynamicArray(const Point arr[], int size)
{ 
    this->size = size;
    this->arr = new Point[size];

    for(int i = 0; i < size; i++)
        this->arr[i] = arr[i];
}
DynamicArray::DynamicArray(const DynamicArray &o)
{
    this->size = o.size;
    this->arr = new Point[o.size];

    for(int i = 0; i < size; i++)
        this->arr[i] = o.arr[i];
}

void DynamicArray::resize(int newSize) {
    Point *tmp = new Point[newSize];
    int minSize = (newSize > size) ? size : newSize;
    for(int i = 0; i < minSize; i++)
        tmp[i] = arr[i];
    delete [] arr;
    size = newSize;
    arr = tmp;
}

void DynamicArray::push_back(Point elem) {
    resize(size + 1);
    arr[size-1] = elem;
}

// Yamil
void DynamicArray::insert(Point elem, int pos){
    resize(size+1);
    for(int j=size-1; j > pos;j--){
        arr[j]= arr[j-1];
    }
    arr[pos]=elem;
}


// Miguel
void DynamicArray :: remove (int pos) {
    if( 0 <= pos and pos < size ){
        for(int i = pos; i <= size - 2; i++) {
            arr[i] = arr[i + 1];
        }
    }
    resize (size - 1);
}

void DynamicArray::clear() {
    resize(0);
}

// Yamil
void DynamicArray::print(){
    for(int i=0;i<this->size;i++){
		std::cout<<"("<<this->arr[i].getX()<<" "<<this->arr[i].getY()<<") ";
	}
	std::cout<<'\n';
}

DynamicArray::~DynamicArray()
{
    delete []arr;
}