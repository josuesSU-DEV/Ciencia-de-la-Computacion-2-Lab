#include <allegro.h>
#include "Mapa.h"


int main()
{
    allegro_init();//inicia la librer�a Allegro
    install_keyboard();//nos permite utilizar las teclas
    install_mouse();
    set_color_depth(32);

    //Inicializacion de la instancia Nivel 1

    //const char filename[]="casita.bmp";
    //const char *filenamePtr=filename;

    int nivel=1;//Elegimos el nivel 1 del juego
    int ejeX=880;//Dimensiones de la ventana
    int ejeY=700;

    set_gfx_mode(GFX_AUTODETECT_WINDOWED,ejeX,ejeY,0,0);

    Mapa noob(nivel,ejeX,ejeY);
    //noob.setNivelMapa(1);

    noob.Mostrar();

    return 0;
}
END_OF_MAIN();


