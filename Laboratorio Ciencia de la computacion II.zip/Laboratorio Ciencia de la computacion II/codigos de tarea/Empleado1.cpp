#include <iostream>
#include<iomanip>
#include<array>
#include<math.h>
#include <ctime>
#include<algorithm>
#include "Empleado1.h"
        Empleado1::Empleado1(std::string nombre,std::string apellido,float salario){
            _nombre=nombre;
            _apellido=apellido;
            _salario=salario;
        }
        void Empleado1::setNombre(std::string nombre){
            _nombre=nombre;
        }
        std::string Empleado1::getNombre(){
            return _nombre;
        }
        void Empleado1::setApellido(std::string apellido){
            _apellido=apellido;
        }
        std::string Empleado1::getApellido(){
            return _apellido;
        }
        void Empleado1::setSalario(float salario){
            _apellido=salario;
        }
        float Empleado1::getSalario(){
            return _salario;
        }
        float Empleado1::bono(){

        }
        float Empleado1::mostrarBono(){

        }
        float Empleado1::sueldoTotal(){

        }
