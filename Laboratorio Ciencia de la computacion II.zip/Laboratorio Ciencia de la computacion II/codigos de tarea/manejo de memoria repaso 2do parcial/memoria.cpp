#include<iostream>
#include<stdio.h>
#include<conio.h>
using namespace std;
//int=4 bytes
//char=1 byte
//float = 4 bytes
//

void function_incrementar(int *ptr){
    *ptr+=1;
}
void incrementar(int &auxi){
    auxi+=1;
}
int main(){
    int arr[5]={1,2,3,4,5};
    int *p=arr;
    cout<<p<<endl;
    cout<<arr<<endl;
    cout<<arr+1<<endl;
    cout<<*arr<<endl;
    cout<<*(arr+1)<<endl;
    cout<<*(p)<<endl;
    cout<<*(p+1)<<endl;
    int aux=4;
    //int *ptrAux=&aux;
    //function_incrementar(ptrAux);
    function_incrementar(&aux);//en vez de pasarle un puntero podemos pasarle tmbn el valor pero con su operador de direccion
    //incrementar(aux);
    cout<<aux<<endl;
    cout<<"------------------------------------------------"<<endl;
    //int a=5;
    //int *ptrA=&a;
    //cout<<a<<endl;
    //a++;
    //cout<<a<<endl;
    int a=1025;
    int *p=&a;
    char *ptrChar;
    ptrChar=(char*)p;//casteando al estilo c
    //hacemos un cambio


    //ptrA+=1;
    
    cout<<*p<<endl;
    cout<<ptrChar<<endl;//en c++ este ptrchar va tomar el castep de p como un string
    //por lo que deberemos imprimir en formato c puro con printf
    printf("El valor de p es  %d",*p);
    cout<<endl;
    printf("La direccion de p es %d",p);
    cout<<endl;
    printf("El valor de pc es %d",*ptrChar);

    cout<<endl;
    //ojo como se hizo el casteo del entero 1025 
    //cout<<a<<endl;                        //esto quiere decir que toma el primer byte del entero 
                                            //esto por el cast que se hizo , ya que un char solo toma 1 byte
                                            //y tomo el primer byte que como recordamos tiene valor 1
    printf("La direccion de pc es %d",ptrChar);
    cout<<endl;
    printf("El valor de p es  %d",*(p+1));//esto es basura ya q despues
    cout<<endl;                           //de los 4 bytes asignados 
                                          //no se sab q sigue
    printf("La direccion de p es %d",p+1);//direccion+1
    cout<<endl;
    printf("El valor de pc es %d",*(ptrChar+1));//
    cout<<endl;
    printf("La direccion de pc es %d",ptrChar+1);
    //ptrChar++;//ojo aca me lleva al siguiente byte que seria 4 
              //esto porque el siguiente byte tiene 100 q es base 2=4 
    
    /*
    printf("La direccion de pc es %d",ptrChar);
    cout<<endl;
    printf("El valor de pc es %d",*ptrChar);
    cout<<endl;
    */
    int probando=261;
    int *ptrProbando=&probando;
    char *pruebaChar;
    pruebaChar=(char*)ptrProbando;
    //printf("valor de prueba char es %d",*pruebaChar);
    int x=5;
    int *p1=&x;
    int **q=&p1;
    int ***r=&q;
    cout<<*p1<<endl;
    getch();
    
    return 0;
}