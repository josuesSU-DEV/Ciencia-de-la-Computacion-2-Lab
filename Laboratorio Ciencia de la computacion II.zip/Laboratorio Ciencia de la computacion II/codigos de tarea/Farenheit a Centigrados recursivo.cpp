#include <iostream>
using namespace std;
float FarenheitCelsius(float num1,float num2){
    if (num2==1){
        return (num1-32)/9;
    }
    else{
        return (num1-32)/9+FarenheitCelsius(num1,num2-1);
    }
}
int main(){  
    cout<<FarenheitCelsius(59,5)<<endl;
    system("PAUSE");
    return 0;
}
