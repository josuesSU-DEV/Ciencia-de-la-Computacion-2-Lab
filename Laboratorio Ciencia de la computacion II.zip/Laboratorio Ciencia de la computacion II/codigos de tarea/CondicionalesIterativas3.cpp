#include <iostream>
#include <math.h>
using namespace std;
void CuadradoCubo(int a, int b){
    cout<<"N\t"<<"cuadrado\t"<<"cubo"<<endl;
    for (int i=a;i<=b;i++){
        cout<<i<<"\t"<<pow(i,2)<<"\t\t"<<pow(i,3)<<endl;
   }
}
int main(){
    int a1,b1;
    cout<<"1.Ingrese el primer numero: ";
    cin>>a1;
    cout<<"2.Ingrese el segundo numero: ";
    cin>>b1;
    (a1>b1? CuadradoCubo(b1,a1):CuadradoCubo(a1,b1));
    system("PAUSE");
    return 0;
}