#include <iostream>
using namespace std;
void Comisiones(){
    float km,litros,kplViaje,kplPromedioContador,nroIteraciones;
    kplPromedioContador=0;
    nroIteraciones=1;
    cout<<nroIteraciones<<".-Ingrese el numero de kilometros usados en el viaje numero "<<nroIteraciones<<" : "<<endl;
    cin>>km;
    while(km!=-1){
        cout<<nroIteraciones<<".-Ingrese el numero de litros usados en el viaje numero "<<nroIteraciones<<" : "<<endl;
        cin>>litros;
        kplViaje=km/litros;
        cout<<"- "<<kplViaje<<" KPL en este viaje : "<<kplViaje<<endl;
        kplPromedioContador+=kplViaje;
        nroIteraciones+=1;
        cout<<nroIteraciones<<".-Ingrese el numero de kilometros usados en el viaje numero "<<nroIteraciones<<" : "<<endl;
        cin>>km;
    }
    cout<<"-El promedio de los KPL en todos los viajes es "<<kplPromedioContador/(nroIteraciones-1)<<endl;
}
int main(){
    Comisiones();    
    system("PAUSE");
    return 0;
}
