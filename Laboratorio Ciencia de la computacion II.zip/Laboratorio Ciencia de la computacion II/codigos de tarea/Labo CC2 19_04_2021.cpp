#include <iostream>
#include<math.h>
#include<conio.h>
#include<math.h>
using namespace std;
//ejercicio 1
int funcionMultiplos3y5(int limite){
    int contador=0;
    for (int i=3;i<limite;i++){
        if(i%3==0||i%5==0){
            contador+=i;
        }
    }
    return contador;
}
/*int PrimoAuxiliar(int numero){
    int contador=0;
    for(int i=1;i<=numero;i++){
        if(numero%i==0){
            contador+=1;
        }
    }
    if(contador>2){
        return false;
    }
    else{
        return true;
    }

}
int factorPrimoMayor(int numero){
    int mayor;
    for (int i=2;i<numero;i++){
        if (numero%i==0 && PrimoAuxiliar(i)==true){
            mayor=i;
        }
    }
    return mayor;
}*/
//ejercicio 2
int Fibonnacci(int numero){
    if(numero==1){
        return 1;
    }
    if(numero==2){
        return 2;
    }
    else{
        return Fibonnacci(numero-1)+Fibonnacci(numero-2);
    }
}
int SumaParesFibonacci(int limite){
    int i=2,contador=0;
    while(Fibonnacci(i)<=limite){
        if(Fibonnacci(i)%2==0 ){
            contador+=Fibonnacci(i);   
        }
        i+=1;
    }
    return contador;
}
//ejercicio 3
long long Primo(long long numero){
    long long mayor;
    for(long long i=2;numero>1;i++){
        while(numero%i==0){
            numero/=i;
            }
        mayor=i;
    }
    return mayor;
}
//ejercicio 4
bool capicua(int numero){//funcion comprueba que es polindromo
    size_t residuo;
    int valorAux=numero,palindromo=0;
    while (valorAux>0){
        residuo=valorAux%10;
        valorAux=valorAux/10;
        palindromo=palindromo*10+residuo;
    }
    if (palindromo==numero){
        return true;
    }    
    else{
        return false;
    }
}
//producto de funciones
long int capicuamax(int n){
    long int aux=0;
    for(int i=999;i>=100;i--){
        for(int j=999;j>=100;j--){
            if(capicua(i*j) == true && i*j>aux){
                aux=i*j;
            }
        }
    }
    return aux;
}
/*long int maximoPalindromo(){

}*/
//ejercicio 5
int MCD(int num1,int num2){
    if(num1==0){
        return  num2;
    }
    else{
        return MCD(num2%num1,num1);
    }
}
/*int MinimoMultiplos(int num) {
    int contador=1;
    if(contador==num){
        return 
    }    
}*/
//ejercicio 6
int Diferencia(int numero){
    return ((numero*(numero+1)*numero*(numero+1))/4)-((numero*(numero+1)*((2*numero)+1))/6);
}
//ejercicio 7
bool ComprobarPrimo(long num){
    long divisores=2;
    bool valor=true;
    if(num<2 && num>0){
        valor=false;
    }
    else{
        while(divisores<=sqrt(num) && valor==true ){
            if(num%divisores==0){
                valor=false;
            }
            divisores+=1;
        }
    }
    return valor;
}
long primoNEsimo(long num){
    long auxNum=2,auxPosicion=0;
    while(auxPosicion<num){
        if(ComprobarPrimo(auxNum)==true){
            auxPosicion+=1;
        }
        auxNum+=1;
        
    }
    return auxNum-1;
}
//ejercicio 8
//ejercicio 9

long TripletePitagorico(){
    for (int a=1; a<1000;a++){
        for (int b=1; b<1000;b++){
            for (int c=1; c<1000;c++){
                if (a*a+b*b==c*c && a+b+c==1000)
                    return a*b*c;
            }
        }
    }
}
//ejercicio 10
long long SumaDePrimos(long long num){
    long long contador=0;
    for(long long i=2;i<num;i++){
        if(ComprobarPrimo(i)==true){
            contador+=i;
        }
    }
    return contador;
}
//ejercicio 11
//ejercicio 12
//ejercicio 13
//ejercicio 14
//ejercicio 15

int main(){
    //cout<<funcionMultiplos3y5(10)<<endl ;
    //cout<<funcionMultiplos3y5(1000)<<endl;
    //cout<<Primo(600851475143)<<endl;
    //cout<<Fibonnacci(4)<<endl;
    //cout<<SumaParesFibonacci(4000000)<<endl;
    //cout<<Diferencia(100)<<endl;
    //int num=7;
    //PrimoAux(121)==1? cout<<"no es primo":cout<< "es primo";
    //cout<<PrimoAux(7)<<endl;
    //cout<<SumaDePrimos(2000000)<<endl;
    //cout<<capicuamax(3);
    //cout<<ComprobarPrimo(15,1)<<endl;
    //cout<<primoNEsimo(10001)<<endl;
    //cout<<TripletePitagorico()<<endl;
    //cout<<SumaDePrimos(2000000)<<endl;
    //cout<<MCD(20,5)<<endl;
    getch();
    return 0;
}
