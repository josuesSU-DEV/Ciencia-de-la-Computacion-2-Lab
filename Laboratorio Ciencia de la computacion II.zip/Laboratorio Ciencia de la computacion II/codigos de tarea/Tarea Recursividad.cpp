#include <iostream>
using namespace std;
bool primo(int num1){
    int count=0;
    for (int i=1;i<=num1;i+=1){
        if (num1%i==0){
            count+=1;
        }
    }
    if (count>2){
        return false;
    }
    else{
        return true;
    }
}
//armando primo recursivo
int primoRecursivo(int num1,int num2){
    if (num1==num2){
        return 1;
    }
    else if (num1%num2==0){
        return 1+primoRecursivo(num1,num2+1);
    }
    else {
        return 0+primoRecursivo(num1,num2+1);
    }
}
int main(){  
    int numero;
    cout<<"Ingrese el numero a evaluar si es primo o no: ";
    cin>>numero;
    if (primoRecursivo(numero,1)==2){
       cout<<"Es primo"<<endl;
    }
    else{
        cout<<"No es primo"<<endl;
    }
    system("PAUSE");
    return 0;
}
