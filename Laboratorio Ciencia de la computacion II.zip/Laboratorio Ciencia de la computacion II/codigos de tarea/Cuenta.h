#include <iostream>
#include <string>
class Cuenta{
    private:
        int _saldoCuenta;
    public:
        Cuenta(int saldoCuenta);
        int getSaldoCuenta()const;
        void mostrarSaldo();
        void abonar(int abonado);
        void cargar(int retiro);
            
};

