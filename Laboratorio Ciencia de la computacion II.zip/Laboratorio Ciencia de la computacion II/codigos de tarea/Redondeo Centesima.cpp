#include <iostream>
using namespace std;
void centesimas(double numero){
    cout<<"El redondeo del numero "<<numero<<" a su centesima es ";
    cout.precision(3);
    cout<<numero<<endl;
}
int main(){
    double numero1=3.454578;
    centesimas(numero1);
    system("PAUSE");
    return 0;
}