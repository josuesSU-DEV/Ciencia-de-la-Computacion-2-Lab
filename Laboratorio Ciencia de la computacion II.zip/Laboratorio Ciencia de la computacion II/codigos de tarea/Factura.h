#include <iostream>
#include <string>
class Factura{
private:
    std::string _codigoArticulo;
    std::string _descripcion;
    int _cantidad;
    int _precio;
public:
    Factura(std::string codigoArticulo,std::string descripcion,int cantidad,int precio);
    std::string getCodigo();
    std::string getDescripcion();
    int getCantidad();
    int getPrecio();
    void obtener();
   
//prototipo de funciones
};
