#include <iostream>
#include<iomanip>
#include<array>
#include<math.h>
#include <ctime>
#include<algorithm>
#include<conio.h>
using namespace std;
class Libro{
    private:
        int ISBN=0,numeroPags=0;
        string autor="Desconocido",titulo="Desconocido"; 
    public:
        Libro(int _ISBN,int _numeroPags,string _autor,string _titulo){
            ISBN=_ISBN;
            numeroPags= _numeroPags;
            autor=_autor;
            titulo=_titulo;
        }
        Libro(string _autor,string _titulo){
            titulo=_titulo;
            autor=_autor;
        }
        void setISBN(int _ISBN){
            ISBN=_ISBN;
        }
        int getISBN(){
            return ISBN;
        }
        void setNumeroPags(int _numeroPags){
            numeroPags=_numeroPags;
        }
        int getNumeroPags(){
            return numeroPags;
        }
        void setAutor(string _autor){
            autor=_autor;
        }
        string getAutor(){
            return autor;
        }
        void setTitulo(string _titulo){
            titulo=_titulo;
        }
        string getTitulo(){
            return titulo;
        }
        void mostrarLibro(){
            cout<<"El libro "<<getTitulo()<<" con ISBN "<<getISBN()<<" creado por el autor "<<getAutor()<<" tiene "<<getNumeroPags()<<" paginas"<<endl;
        }
        ~Libro(){}

};
int main(){
    int ISBN,numeroPags;
    string autor,titulo;
    cout<<"--------------------Conociendo todos los datos----------------------"<<endl;
    cout<<"Ingrese el ISBN del libro: ";
    cin>>ISBN;
    cout<<"Ingrese los numeros de paginas: ";
    cin>>numeroPags;
    cout<<"Ingrese el autor: ";
    cin>>autor;
    cout<<"Ingrese el titulo: ";
    cin>>titulo;
    Libro instancia(ISBN,numeroPags,autor,titulo);
    instancia.mostrarLibro();
    instancia.~Libro();
    cout<<"--------------------Desconociendo el ISBN y el numero de paginas----------------------"<<endl;
    cout<<"Ingrese el autor: ";
    cin>>autor;
    cout<<"Ingrese el titulo: ";
    cin>>titulo;
    Libro instancia2(autor,titulo);
    instancia2.mostrarLibro();
    instancia.~Libro();
    getch();
    return 0;
}