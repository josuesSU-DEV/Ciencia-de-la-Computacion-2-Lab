#include <iostream>
#include<iomanip>
#include<array>
#include<math.h>
#include <ctime>
#include<algorithm>
using namespace std;
class Rectangulo{
    private:
        float _ancho;
        float _largo;
    public:
    Rectangulo(float ancho,float largo){
        _ancho=ancho;
        _largo=largo;
    }
    float area(){
        return _ancho*_largo;
    }
    float perimetro(){
        return (2*_ancho)+(2*_largo);
    }
    void setRect(float ancho,float largo){
        _ancho=ancho;
        _largo=largo;
    }
    float getRectAncho(){
        return _ancho;
    }
    float getRectLargo(){
        return _largo;
    }

};
class Circulo{
    private:
        float _radio;
    public:
    Circulo(float radio){
        _radio=radio;
    }
    float area(){
        return (3.14)*_radio*_radio;
    }
    float perimetro(){
        return 2*3.14*_radio;
    }
    void setRadio(float radio){
        _radio=radio;
    }
    float getRadio(){
        return _radio;
    }
    

};
int main(){
    Rectangulo instancia(3,4);
    cout<<"area de rectangulo es "<<instancia.area()<<endl;
    cout<<"perimetro de rectangulo es "<<instancia.perimetro()<<endl;
    Circulo instancia2(3);
    cout<<"area de circulo es "<<instancia2.area()<<endl;
    cout<<"perimetro de circulo es "<<instancia2.perimetro()<<endl;
    system("PAUSE");

    return 0;
}