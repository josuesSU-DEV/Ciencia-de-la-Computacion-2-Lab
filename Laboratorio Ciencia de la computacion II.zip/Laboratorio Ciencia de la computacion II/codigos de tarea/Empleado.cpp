#include<iostream>
#include "Empleado.h"
using namespace std;
Empleado::Empleado(std::string nombre,std::string apellido,int salario){
    _nombre=nombre;
    _apellido=apellido;
    _salario=salario;
}
void Empleado::setNombre(std::string nombre1){
    _nombre=nombre1;
}
void Empleado::setApellido(std::string apellido1){
    _apellido=apellido1;
}
void Empleado::setSalario(int salario1){
    _salario=salario1;
}
string Empleado::getNombre(){
    return _nombre;
}
string Empleado::getApellido(){
    return _apellido;
}
int Empleado::getSalario(){
    return _salario;
}
void Empleado::salarioAnual(){
    cout<<"El salario anual del empleado "<<getNombre()<<" "<<getApellido()<<" es de "<<getSalario()*12<<endl;
}