#include <iostream>
#include<math.h>
#include"Calculadora.cpp"
using namespace std;

int main(){
    float a,b;
    cout<<"-------------------------------------------------------------------"<<endl;
    cout<<"Primer objeto"<<endl;
    cout<<"Ingrese el primer numero: ";
    cin>>a;
    cout<<"Ingrese el segundo numero: ";
    cin>>b;
    Calculadora Instancia(a,b);//Instancia del primer objeto
    Instancia.suma();
    Instancia.resta();
    Instancia.multiplicacion();
    Instancia.division();
    Instancia.potencia();
    system("PAUSE");
    return 0;
}