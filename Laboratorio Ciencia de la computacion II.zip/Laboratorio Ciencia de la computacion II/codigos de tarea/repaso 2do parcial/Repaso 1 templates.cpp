#include<iostream>
#include<conio.h>
using namespace std;
//modelo de template:


/*

template<typename T> ó template<class T> 

//entonces typename y class es lo mismo

//mas recomendable es usar typename para no confundir con una clase


type name_function(type parameter_1,type parameter_2){
    return paramater_1(+/-*)parameter_2
}

//al invocar:
name_function<type>(paramter_1,paramter_2)

*/

// con un templates:
template<typename T>
T suma(const T a, const T b){//en tiempo de compilacion o cuando se use se reemplazara con el tipo que se defina
    return a+b;
}
//para ejecutar seria:
//  suma<type>(parameters)


// con dos templates:
template<typename T,typename U>
U sum(const T a, const U b){
    return a+b;
}

int main(){

    cout<<suma<int>(3,4)<<endl;//siempre especificar el tipo
    cout<<suma<float>(3.5,4.6)<<endl;
    
    
    //2 templates:

    cout<<sum<int,float>(3,4.9)<<endl;

    getch();
    return 0;
}