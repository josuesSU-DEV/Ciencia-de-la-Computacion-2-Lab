#include<iostream>
using namespace std;
#include<conio.h>
//clase generica Point sin separar en .h y .cpp

/*
template<typename T>
class Point{
    private:
        T x,y;
    public:
        Point(const T u,const T v):x(u),y(v){}
        T getX(){return x;}
        T getY(){return y;}

};
*/
int main(){
    //Point <float> instancia(3.5,4.5);//si cambias el type por int te casteara a 3,4
    //cout<<"( "<<instancia.getX()<<" , "<<instancia.getY()<<" )";
    getch();
    return 0;
}
