#include "Point.h"
template<typename T>
class DynamicArray
{
private:
    T *arr;
    int size;
public:
    DynamicArray();
    DynamicArray(const T arr[], int size);
    DynamicArray(const DynamicArray &o);

    void push_back(T elem);
    //metodos auxiliares para hacer notorio los metodos que se nos asigno como tarea
    void LLenarArray();
    void ImprimirArray();
    // tarea 
    void insert(T elem, int pos);
    void remove(int pos);

    int getSize() const {
        return size;
    }

    ~DynamicArray();
};
