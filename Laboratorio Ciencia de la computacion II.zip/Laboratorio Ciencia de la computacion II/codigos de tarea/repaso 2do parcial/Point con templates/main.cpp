#include<iostream>
#include<conio.h>
#include<set>//libreria para una estructura de datos llamada conjunto
#include<algorithm>//libreria para hacer busqueda binaria
#include"Point.h"
using namespace std;
//se recomienda enviarlo a un .h para no pasar problemas

//clase generica:

template<typename T>
class Container{
    private:
        T elt;
    public:
        Container(const T arg){
            elt=arg;
        }
        T inc(){
            return elt++;
        }
};

//Clase especializada para un tipo:
//en este caso especializada para un char


template<>
class Container<char>{//aqui va un < type>
    private:
        char elt;
    public:
    Container(const char arg){
        elt=arg;
    }
    char uppercase(){
        return toupper(elt);
    }
};


//con varios y tipos especificos
//esto es un generico con un entero
template<typename T,int N>
class ArrayContainer{
    private:
        T elts [N];
    public:
        ArrayContainer(){
            for(int i=0;i<N;i++){elts[i]=0;}//me iguala todos los valores a 0 por defecto de la lista
        }
        T set(const int i,const T val){
            elts[i]=val;
        }
        T get(const int i){
            return elts[i];
        }
};

//si queremos un array por defecto, es decir con un tipo y tamaño por defecto entonces en la parte del template pondremos:
//template<typename T=int,int N=5>
//en el main pondriamos:
//ArrayContainer<>instancia , lo q hace esto es q me crea un arreglo por fecto con valores tupo int y tamaño 5
 
using namespace std;
int main(){
    Point<int> uno(3.5,4.5);
    //cout<<uno.getX();
    ArrayContainer<int,5>instanciaArray;
    ArrayContainer<float,10>instanciaArray2;
    instanciaArray.set(2,3);
    instanciaArray2.set(3,3.5);
    cout<<instanciaArray.get(1)<<endl;
    cout<<instanciaArray.get(2)<<endl;
    cout<<instanciaArray2.get(1)<<endl;
    cout<<instanciaArray2.get(2)<<endl;
    cout<<instanciaArray2.get(3)<<endl;
    int arr[3]={17,29,38};
    cout<<"repasando arreglo"<<endl;
    int * ptr=arr;
    cout<<*(++ptr)<<endl;
    set<int>instancia;
    instancia.insert(5);
    instancia.insert(8);
    instancia.insert(7);
    instancia.insert(9);
    instancia.insert(11);
    cout<<"El iset contiene: ";
    set<int>::iterator it;
    for(it=instancia.begin();it !=instancia.end();it++){
        cout<<" "<<*it;
    cout<<endl;
    }
    int searchFor;
    cin>>searchFor;
    if(binary_search(instancia.begin(),instancia.end(),searchFor)){
        cout<<"Encontrado"<<searchFor<<endl;
    }
    else{
        cout<<"No encontrado";
    }
    getch();
    return 0;

}