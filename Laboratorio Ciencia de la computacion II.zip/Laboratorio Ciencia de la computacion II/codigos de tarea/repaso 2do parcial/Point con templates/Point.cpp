#include "Point.h"
template<typename T>
T Point<T>::Point(T u,T v){
    x=u;
    y=v;
}
template<typename T>
T Point<T>::getX(){return x;}
template<typename T>
T Point<T>::getY(){return y;}