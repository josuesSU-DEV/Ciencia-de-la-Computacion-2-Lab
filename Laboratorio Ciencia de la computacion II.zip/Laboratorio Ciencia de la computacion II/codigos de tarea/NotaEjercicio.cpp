#include <iostream>
using namespace std;
int main(){
    int calificacion;
    cout<<"A.-Ingrese la calificacion: ";
    cin>>calificacion;
    calificacion=calificacion%2;
    switch (calificacion)
    {
    case 0:
        cout<<"Par"<<endl;
        break;
    case 1:
        cout<<"Impar"<<endl;
        break;
    }
    system("PAUSE"); 
    return 0;   
}