#include <iostream>
#include<math.h>
#include<string>
class Calculadora{
    private:
        float _num1;
        float _num2;
    public:
        Calculadora(float num1,float num2);
        float getNum1();
        float getNum2();
        std::string suma();
        std::string resta();
        std::string multiplicacion();
        std::string division();
        std::string potencia();
};
//prototipos

