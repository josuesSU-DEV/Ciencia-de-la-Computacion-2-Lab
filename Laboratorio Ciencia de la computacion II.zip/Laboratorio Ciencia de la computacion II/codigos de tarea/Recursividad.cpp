#include<iostream>
#include "Recursividad.h"
using namespace std;
int Recursividad::fibonacci(int num1){
    if (num1==1){
        return 0;
    }
    else if (num1==2){
        return 1;
    }
    else{
        return fibonacci(num1-1)+fibonacci(num1-2);
    }
}
int Recursividad::factorial(int num1){
    if (num1==2){
        return 2;
    }
    else{
        return num1*factorial(num1-1);
        }
    } 
int Recursividad::MCD(int num1,int num2){
    if(num1==0){
        return num2;
    }
    else{
        return MCD(num2%num1,num1);
        }
}
int Recursividad::MCM(int num1,int num2){
    return (num1*num2)/MCD(num1,num2);
} 