#include <iostream>
using namespace std;
bool analisarNota(int nota){//Funcion que permitiraaa saaber si la anota es o no aprobatoria
    if (nota>=0 && nota<=20){
        if (nota<10){
            cout<<"Desaprobado"<<endl;
            return false;
        }
        else{
            cout<<"Aprobado"<<endl;
            return true;
        }
    }
    else{
        cout<<"Nota ingresada invalida, se considerara desaprobado"<<endl;
        return false;
    }
}
int main(){
    float aprobados,desaprobados;
    int calificacion;
    cout<<"-Ingrese la calificacion: ";
    cin>>calificacion;
    while(calificacion!=-1){
        bool d=analisarNota(calificacion);
        if (d==true){
            aprobados+=1;
        }
        else if (d==false){
            desaprobados+=1;
        }
        cout<<"------------------------------------------------------------------------------------------------"<<endl;
        cout<<"-Ingrese la calificacion: ";
        cin>>calificacion;
    }
    if ((aprobados+desaprobados)/2<aprobados){
        cout<<"El instructor merece un bono"<<endl;
    }
    else{
        cout<<"No se pagara bono"<<endl;
    }
    cout<<"El numero de aprobados es "<<aprobados<<endl;
    cout<<"El numero de aprobados es "<<desaprobados<<endl;
   system("PAUSE"); 
    return 0;   
}