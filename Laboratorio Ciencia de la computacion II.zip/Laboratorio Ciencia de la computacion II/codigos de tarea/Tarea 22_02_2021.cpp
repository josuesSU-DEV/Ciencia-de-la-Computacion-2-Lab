#include <iostream>
#include<iomanip>
#include<array>
#include<math.h>
#include <ctime>
#include<algorithm>
//ejercicio 7 al 11
using namespace std;
const size_t longitud=10;
const size_t longitudArregloUnico=20;
const size_t longitudDado=6;
//ejercicio 7
void Asignar450(array<int,longitud> arreglo);
void darBono(array<int,longitud> arreglo);
void mostrarArregloOriginal(array<int,longitud> arreglo);
void busqueda();
//ejercicio 8
void darBonoDinamico(array<int,longitud>& arreglo);
void mostrarMayor(const array<int,longitud>arreglo);
void ordenarArregloDinamico(array<int,longitud>& arreglo);
//ejercicio9
void darValores(array<int,longitudArregloUnico>& arreglo);
//ejercicio 10
void almacenarBiDado(array<array<int,longitudDado>,longitudDado>& arreglo);
int lanzarDado();
int main(){
    srand(time(0));
    array<int,longitud>arregloSemiDinamico={};
    //Ejercicio 9
    array<int,longitudArregloUnico>arregloNumerosUnicos={};
    array<array<int,longitudDado>,longitudDado>arregloDados={};
    //ejercicio7
    /*Asignar450(arregloSemiDinamico);
    cout<<"Arreglo con Bono"<<endl;
    darBono(arregloSemiDinamico);
    cout<<"Arreglo original"<<endl;
    mostrarArregloOriginal(arregloSemiDinamico);
    //ejercicio 8
    cout<<"Arreglo con Cambio dinamico"<<endl;
    darBonoDinamico(arregloSemiDinamico);
    cout<<"Arreglo ordenado"<<endl;
    ordenarArregloDinamico(arregloSemiDinamico);
    cout<<"Mostrando mayor"<<endl;
    mostrarMayor(arregloSemiDinamico);*/
    //ejercicio 9
    //cout<<"Numeros del 10 al 100"<<endl;
    //darValores(arregloNumerosUnicos);
    almacenarBiDado(arregloDados);

    system("PAUSE");
    return 0;
}
void Asignar450(array<int,longitud> arreglo){
    for(int i=0;i<longitud;i++){
        arreglo[i]=450;
    }
    for(size_t element:arreglo){
        cout<<element<<endl;
    }
}
void darBono(array<int,longitud> arreglo){
    size_t bonoImpar;
    for(int i=0;i<longitud;i++){
        arreglo[i]=450;
    }
    for(int i=0;i<longitud;i++){
        if((i+1)%2==0){
            arreglo[i]+=200;
        }
        else{
            cout<<"Ingrese el valor a agregar a la posicion impar: ";
            cin>>bonoImpar;
            arreglo[i]+=bonoImpar;
        }
    }
    for(size_t element:arreglo){
        cout<<element<<endl;
    }
}
void mostrarArregloOriginal(array<int,longitud> arreglo){
    for(size_t element:arreglo){
        cout<<element<<endl;
    }
}
//ejercicio 8
//para esto debemos hacer los anteriores metodos pero cambiando los valores solo utilizaremos la funcion darBono para ordenar y dar el mayor
void darBonoDinamico(array<int,longitud>& arreglo){
    size_t bonoImpar;
    for(int i=0;i<longitud;i++){
        arreglo[i]=450;
    }
    for(int i=0;i<longitud;i++){
        if((i+1)%2==0){
            arreglo[i]+=200;
        }
        else{
            cout<<"Ingrese el valor a agregar a la posicion impar: ";
            cin>>bonoImpar;
            arreglo[i]+=bonoImpar;
        }
    }
    for(size_t element:arreglo){
        cout<<element<<endl;
    }
}
int lanzarDado(){
    return rand()%6+1;
}
void ordenarArregloDinamico(array<int,longitud>& arreglo){
    sort(arreglo.begin(),arreglo.end());
    for(size_t element:arreglo){
        cout<<element<<endl;
    }
}
void mostrarMayor(const array<int,longitud>arreglo){
    cout<<"El mayor es "<<arreglo[longitud-1]<<endl;
}
//ejercicio 9
/*void darValores(array<int,longitudArregloUnico>& arreglo){
    int valor;
    for(int i=0;i<longitudArregloUnico;i++){
        cout<<"Ingrese un numero del 10 al 100 ";
        cin>>valor;
        
        if(valor>=10 && valor<=100){
            sort(arreglo.begin(),arreglo.end());
            if(binary_search(arreglo.begin(),arreglo.end(),valor)==true){
                cout<<"Numero identico "<<endl;
                arreglo[i]=0;
            }
            else{
                arreglo[i]=valor;
            }
        }
    }
    for(size_t element:arreglo){
        cout<<element<<endl;
    }
}*/
void darValores(array<int,longitudArregloUnico>& arreglo){
    int valor;
    for(int i=0;i<longitudArregloUnico;i++){
        //sort(arreglo.begin(),arreglo.end());
        cout<<"Ingrese un numero del 10 al 100 ";
        cin>>valor;
        if(valor>=10 && valor<=100){
            if (binary_search(arreglo.begin(),arreglo.end(),valor)==false){
                arreglo[i]=valor;
            }
    }
    }
    cout<<"Valores Unicos"<<endl;
    sort(arreglo.begin(),arreglo.end());
    for(int i=1;i<longitudArregloUnico;i++){
        if(i==0){
            cout<<arreglo[i]<<endl;
        }
        else {
            for(i=1;i<longitudArregloUnico;i++){
                if(arreglo[i]!=arreglo[i-1]){
                    cout<<arreglo[i]<<endl;
                }
            }
            
        }
    }
}
void almacenarBiDado(array<array<int,longitudDado>,longitudDado>& arreglo){
    for (int i=0;i<10000;i++){
        arreglo[lanzarDado()-1][lanzarDado()-1]+=1;
    }
    for(int i=0;i<longitudDado;i++){
        for(int j=0;j<longitudDado;j++){
            cout<<arreglo[i][j]<<" "; 
        }
        cout<<endl;
    }
}
