#include <iostream>
#include<conio.h>
#include<stdlib.h>
long long tamanio=1000;
long long *arregloDin;
using namespace std;
void llenarLista(){
    arregloDin=new long long[tamanio];
    for(long long i=0;i<tamanio;i++){
        /*cout<<"Ingrese el valor: ";
        cin>>arreglo[i];//=i+1;*/
        arregloDin[i]=i+1;
    }
}
void mostrarLista(long long arreglo[],long long tamanio){
    cout<<"Lista: "<<endl;
    for(long long i=0;i<tamanio;i++){
        cout<<arreglo[i]<<endl;
    }
}
long long sum( long long arreglo[],long long tamanio){
    //cout<<"Suma"<<endl;
    long long suma=0;
    /*for (int i=0;i<tamanio;i++){
        suma+=arreglo[i];
    }*/
    for(long long i=0;i<tamanio;suma+=arreglo[i++]);
    return suma;
}
/*long long sumRec(int arreglo[],long long tamanio){
    //cout<<"Suma"<<endl;
    long long suma=0;
    if(tamanio==0){
        return arreglo[0];
    }
    else{
        suma+=arreglo[tamanio]+sumRec(arreglo,tamanio-1);
    }
    return suma;
}*/
long long sumRec(long long arreglo[],long long tamanio){
    long long suma=0;  
    return tamanio==0?arreglo[0]:suma+=arreglo[tamanio]+sumRec(arreglo,tamanio-1);
}
int main(){
    llenarLista();
    //mostrarLista(arregloDin,tamanio);
    //cout<<sum(arregloDin,tamanio);
    cout<<sumRec(arregloDin,tamanio-1);
    delete [] arregloDin;
    getch();
    return 0;
    
}