#include <iostream>
#include "Cuenta.cpp"
using namespace std;

int main()
{
    int saldoIngresar,cargado,abonado,saldoIngresar2,cargado2,abonado2;
    cout<<"-------------------------------------------------------------------"<<endl;
    cout<<"Primer objeto"<<endl;
    cout<<"Ingrese el saldo: ";
    cin>>saldoIngresar;
    Cuenta Instancia(saldoIngresar);//Instancia del primer objeto
    cout<<"Ingrese el saldo a retirar: ";
    cin>>cargado;
    Instancia.cargar(cargado);
    cout<<"Ingrese el saldo a abonar: ";
    cin>>abonado;
    Instancia.abonar(abonado);
    //Segundo objeto
    cout<<"-------------------------------------------------------------------"<<endl;
    cout<<"Segundo objeto"<<endl;
    cout<<"Ingrese el saldo: ";
    cin>>saldoIngresar2;
    Cuenta Instancia2(saldoIngresar2);
    cout<<"Ingrese el saldo a retirar: ";
    cin>>cargado2;
    Instancia2.cargar(cargado2);
    cout<<"Ingrese el saldo a abonar: ";
    cin>>abonado2;
    Instancia2.abonar(abonado2);
    cout<<"-------------------------------------------------------------------"<<endl;
    Instancia.mostrarSaldo();
    Instancia2.mostrarSaldo();
    system("PAUSE");
    return 0;

}