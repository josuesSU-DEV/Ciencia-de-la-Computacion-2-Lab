#include <iostream>
using namespace std;
int main()
{
    float a,b;
    cout<<"Hola bienvenido a la calculadora de ecuacion de forma a*b/a+b: \n";
    cout<<"Ingrese su primer numero: ";
    cin>>a;
    cout<<"Ingrese su segundo numero: ";
    cin>>b;
    cout<<(a*b)/(a+b)<<endl;
    system("PAUSE");
    return 0;

}