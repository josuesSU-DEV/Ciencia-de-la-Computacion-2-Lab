#include <iostream>
using namespace std;
void Cuadrado(int longitud){
    for (int i=1;i<=longitud;i++){
        cout<<"*";
    }
    cout<<endl;
    for (int j=1;j<=longitud-2;j++){
        cout<<"*";
        for (int k=1;k<=longitud-2;k++){
            cout<<" ";
        }
        cout<<"*"<<endl;
    }
    for (int l=1;l<=longitud;l++){
        cout<<"*";
    }
cout<<endl;
}
int main(){
    Cuadrado(5);    
    system("PAUSE");
    return 0;
}
