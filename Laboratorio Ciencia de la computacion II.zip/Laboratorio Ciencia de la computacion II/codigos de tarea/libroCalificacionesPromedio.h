#include <iostream>
#include <string>
class LibroCalificacionesPromedio{
    private:
        int _calificacion;
        /*int _acumulado;
        int _nroAlumnos;*/
    public:
        LibroCalificacionesPromedio(int calificacion1);
        int getCalificacion() const;
        void setCalificacionPromedio(int calificacion2);
        int promedio();

};
//prototipos

        /*int _acumulado;
        int _nroAlumnos;
        LibroCalificacionesPromedio(int nroAlumnos);
        int getCalificacion() const;
        void setCalificacion(int nroAlumnos1);
        int promedio();*/