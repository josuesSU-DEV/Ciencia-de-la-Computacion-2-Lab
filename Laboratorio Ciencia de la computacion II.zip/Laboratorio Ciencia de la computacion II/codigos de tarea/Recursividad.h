#include <iostream>
class Recursividad{
    public:
        int fibonacci(int num1);
        int factorial(int num1);
        int MCD(int num1,int num2);
        int MCM(int num1,int num2);
};

