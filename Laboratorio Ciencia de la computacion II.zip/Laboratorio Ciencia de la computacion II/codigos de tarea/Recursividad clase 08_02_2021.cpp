#include <iostream>
#include <math.h>
#include <ctime>
using namespace std;

int lanzarDado();
void frecuenciaDado();
int numerosAleatorios();
int cuadrado();
void columnaFilaAleatorio(int ,int );
void distanciaPuntos();
void hipotenusaFuncion(float,float,float &);
int fibo(int);
int fact(int);
int sumaNumeros(int);
int potencia(int,int);
int main(){ 
    float co,ca,h;
    co=3;
    h=0;
    ca=4;
    int n=7;
    /*srand(static_cast<unsigned int>(time(0)));
    distanciaPuntos();//tarea2
    columnaFilaAleatorio(3,5);//tarea 1*/
    /*cout<<"La hipotenusa inicialmente es "<<h<<" pasandolo por una funcion por referencia me dara ";
    hipotenusaFuncion(co,ca,h);
    cout<<h<<endl;*/
    //cout<<fibo(7)<<endl;
    for (int i=1;i<=n;i++){
        cout<<fibo(i)<<" , ";
    }
    cout<<endl;
    cout<<"Factorial de  6 es "<<fact(6)<<endl;
    cout<<"La suma sucesiva hasta 11 es "<<sumaNumeros(11)<<endl;
    cout<<"Potencia de 3 a la 4 "<<potencia(3,4)<<endl;
    system("PAUSE");
    return 0;


}
void distanciaPuntos(){
    int a=numerosAleatorios();
    int a1=numerosAleatorios();
    int b=numerosAleatorios();
    int b1=numerosAleatorios();
    cout<<"la distancia entre el punto "<<"("<<a<<" , "<<a1<<")"<<" y el punto "<<"("<<b<<" , "<<b1<<")"<<" es ";
    cout<<sqrt(pow((a-b),2)+pow((a1-b1),2))<<endl;
}

int numerosAleatorios(){
    return rand();

}
void columnaFilaAleatorio(int a ,int b){
    for (int i=1;i<=a;i++){
        for (int j=1;j<=b;j++){
            cout<<numerosAleatorios()<<"\t";
        }
        cout<<endl;
    }
}
int lanzarDado(){
    return rand()%6+1;
}
void frecuenciaDado(){
    int frec1=0;
    int frec2=0;
    int frec3=0;
    int frec4=0;
    int frec5=0;
    int frec6=0;
    for (int i=1;i<=10000;i++){
        
        switch (lanzarDado())
        {
        case 1:
            frec1+=1;
            break;
        case 2:
            frec2+=1;
            break;
        case 3:
            frec3+=1;
            break;
        case 4:
            frec4+=1;
            break;
        case 5:
            frec5+=1;
            break;
        case 6:
            frec6+=1;
            break;
        default:
            break;
        }
    }
    cout<<"El numero de veces que salio 1 es"<<frec1<<endl;
    cout<<"El numero de veces que salio 2 es"<<frec2<<endl;
    cout<<"El numero de veces que salio 3 es"<<frec3<<endl;
    cout<<"El numero de veces que salio 4 es"<<frec4<<endl;
    cout<<"El numero de veces que salio 5 es"<<frec5<<endl;
    cout<<"El numero de veces que salio 6 es"<<frec6<<endl;
}
void hipotenusaFuncion(float cateto1,float cateto2,float &hipotenusa){
    hipotenusa=sqrt(pow(cateto1,2)+pow(cateto2,2));
}
int fibo(int numero){
    if (numero==1){
        return 0;
    }
    else if (numero==2){
        return 1;
    }
    else{
        //cout<<fibo(numero-1);
        //cout<<fibo(numero-2);
        return fibo(numero-1)+fibo(numero-2);
    }
}
int fact(int numero){
    if (numero==1){
        return 1;
    
    }
    else{
        return numero*fact(numero-1);
    }
}
int sumaNumeros(int numero){
    if(numero==1){
        return 1;
    }
    else{
        return numero+sumaNumeros(numero-1);
    }
}
/*int cantidadDigitos(int numero){
    if (numero%10==numero){
        return 1
    }
    else {

    }
}*/
int potencia(int numeroBase,int exponente){
    if (exponente==1){
        return numeroBase;
    }
    else{
        return numeroBase*potencia(numeroBase,exponente-1);
    }
}