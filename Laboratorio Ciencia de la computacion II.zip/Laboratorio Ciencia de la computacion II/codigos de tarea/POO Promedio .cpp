#include <iostream>
#include "Promedio.cpp"
using namespace std;
int main(){
    Promedio Instancia(0);
    Instancia.promedioCentinela();
    system("PAUSE"); 
    return 0;   
}