#include <iostream>
using namespace std;
void Comisiones(){
    float a;
    for (int i=1;i<=10;i++){
        cout<<i<<". Ingrese la venta bruta del vendedor "<<i<<": ";
        cin>>a;
        cout<<"-El sueldo del vendedor"<<i<<" es "<<200+9*a/100<<endl;
    }
}
int main(){
    Comisiones();    
    system("PAUSE");
    return 0;
}