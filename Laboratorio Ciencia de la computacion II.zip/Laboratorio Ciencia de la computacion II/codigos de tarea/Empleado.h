#include<iostream>
#include <string>
class Empleado{
    private:
        std::string _nombre;
        std::string _apellido;
        int _salario;
    public:
        Empleado(std::string nombre,std::string apellido,int salario);
        void setNombre(std::string nombre1);
        void setApellido(std::string apellido1);
        void setSalario(int salario1);
        std::string getNombre();
        std::string getApellido();
        int getSalario();
        void salarioAnual();
};
//prototipo
