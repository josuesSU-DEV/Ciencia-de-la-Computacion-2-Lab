#include<iostream>
#include<conio.h>
using namespace std;
int sumaElemArreglo(int arr[],int tam){
    int count=0;
    for(int i=0;i<tam;i++)
        count+=arr[i];
    return count;
}
int sumaElemArreglo2(int *arr,int tam){
    int count=0;
    for(int i=0;i<tam;i++)
        count+=*(arr+i);
    return count;
}

int main(){
    int a []={1,2,3};
    int bidimensional[2][3]={{1,3,4},{5,7,9}};
    //cout<<sumaElemArreglo(a,3)<<endl;
    //cout<<sumaElemArreglo2(a,3)<<endl;
    int (*p)[3]=bidimensional;
    cout<<bidimensional<<endl;
    
    cout<<*bidimensional<<endl;
    cout<<bidimensional[0]<<endl;
    cout<<&bidimensional[0][0]<<endl;
    cout<<p<<endl;
    cout<<bidimensional+1<<endl;//esto es equivalente a = B[1] osea el segundo arreglo de 3 dimensiones
    cout<<&bidimensional[1]<<endl;
    cout<<bidimensional[1]<<endl;
    cout<<*(bidimensional+1)<<endl;
    cout<<&(bidimensional[1][0])<<endl;
    
    getch();
    return 0;
}