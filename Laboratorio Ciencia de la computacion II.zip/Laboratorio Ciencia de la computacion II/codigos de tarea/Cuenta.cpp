#include <iostream>
//#include <string>
#include "Cuenta.h"
using namespace std;
Cuenta::Cuenta(int saldoCuenta){
    if (saldoCuenta>0){
        _saldoCuenta=saldoCuenta;
        }
    else{
        _saldoCuenta=0;
        cout<<"El saldo ingresado es invalido "<<endl;
        }
    }
int Cuenta::getSaldoCuenta()const{
    return _saldoCuenta;
    }
void Cuenta::mostrarSaldo(){
        cout<<"Su saldo es de "<<getSaldoCuenta()<<endl;
    }
void Cuenta::abonar(int abonado){
    _saldoCuenta+=abonado;
    }
void Cuenta::cargar(int retiro){
    if (retiro>_saldoCuenta){
        cout<<"El monto excede a el saldo de la cuenta , la operacion no se realizo"<<endl;
        _saldoCuenta=0;
    }
    else{
        _saldoCuenta-=retiro;
        }
    }

