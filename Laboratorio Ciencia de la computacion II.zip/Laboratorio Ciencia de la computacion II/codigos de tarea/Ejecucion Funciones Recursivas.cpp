#include <iostream>
#include "Recursividad.cpp"
using namespace std;
int main(){
    int numero1,numero2;
    Recursividad instancia;
    cout<<"Ingrese el numero de Fibonacci que quiere hallar ";
    cin>>numero1;
    cout<<"Ingrese el numero que quiere hallar el factorial ";
    cin>>numero2;
    cout<<"El numero de fibonacci "<<numero1<<" es "<<instancia.fibonacci(numero1)<<endl;
    cout<<"El numero factorial de "<<numero2<<" es "<<instancia.factorial(numero2)<<endl;
    cout<<"El MCM de "<<numero1<<" y "<<numero2<<" es "<<instancia.MCM(numero1,numero2)<<endl;
    cout<<"El MCD de "<<numero1<<" y "<<numero2<<" es "<<instancia.MCD(numero1,numero2)<<endl;
    system("PAUSE");
    return 0;
}
