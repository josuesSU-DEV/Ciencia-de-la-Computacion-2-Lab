#include <iostream>
#include<iomanip>
#include<array>
#include<math.h>
#include <ctime>
#include<algorithm>
using namespace std;
int main(){
    
    system("PAUSE");

    return 0;
}