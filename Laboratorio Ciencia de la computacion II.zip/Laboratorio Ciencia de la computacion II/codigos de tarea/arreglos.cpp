#include <iostream>
#include<iomanip>
#include<array>
#include<math.h>
#include <ctime>
#include<algorithm>
using namespace std;
int serieFibonacci(int numero){
    if (numero==0){
        return 0;
    }
    else if(numero==1){
        return 1;
    }
    else{
        return serieFibonacci(numero-1)+serieFibonacci(numero-2);
    }
}
int lanzarDado(){
    return rand()%6+1;
}
void almacenarNotas(int tamanio){
    int notas[tamanio];
    string alumnos[tamanio];
    int calif=0;
    string nombre;
    for (int i=0;i<tamanio;i++){
        cout<<i+1<<". Ingrese el nombre del alumno: ";
        cin>>nombre;
        alumnos[i]=nombre;
        cout<<i+1<<". Ingrese la nota del alumno: ";
        cin>>calif;
        notas[i]=calif;
    }
    cout<<"-------------------Las notas son---------------------------"<<endl;
    cout<<"  Alumno\tCalificacion"<<endl;
    for (int j=0;j<tamanio;j++){
        cout<<j+1<<"  "<<alumnos[j]<<"\t\t"<<notas[j]<<endl;
    }
}
int main(){
    //int longitud;
    /*int nota=0;
    int longitud;
    cout<<"Ingrese la longitud de la lista: ";
    cin>>longitud;
    int fibonacci[longitud];
    for (int i=0;i<longitud;i++){
        fibonacci[i]=serieFibonacci(i);
    }
    for (int j=0;j<longitud;j++){
        cout<<fibonacci[j]<<endl;
    }
    //srand(static_cast<unsigned int>(time(0)));
    //int const longitud=10000;
    int const longitud=6;
    array <int,longitud> notasAlumnos={};
    for (int i=0;i<20;i++){
        cout<<"Ingrese la nota: ";
        cin>>nota;
        notasAlumnos[nota]+=1;
    }
    cout<<"Nota"<<"\t"<<"Frecuencia"<<endl;
    for (int j=0;j<longitud;j++){
        cout<<j<<"\t"<<notasAlumnos[j]<<endl;
    }
    cout<<"Nota\t"<<"Frecuencia en asteriscos"<<endl;
    for (int k=0;k<longitud;k++){
        cout<<k<<"\t";
        for (int l=0;l<notasAlumnos[k];l++){
            cout<<"*";
        }
        cout<<endl;
    }*/
    //frecuencia de caras
    const int longitud=6;
    array <int,longitud>frecuenciaDado={};
    srand(time(0));
    //frecuenciaDado[lanzarDado()]++;
    for (int i=0;i<200;i++){
        frecuenciaDado[(lanzarDado()-1)]++;
    }
    
    cout<<"Cara\t"<<"frecuencia"<<endl;
    for (int j=0;j<longitud;j++){
        cout<<j+1<<"\t"<<frecuenciaDado[j]<<endl;
    }
    cout<<"Lista ordenada"<<endl;
    sort (frecuenciaDado.begin(),frecuenciaDado.end());
    for (int j=0;j<longitud;j++){
        cout<<frecuenciaDado[j]<<endl;
    }
    
    //problema 1 ejercicio 11
    /*int calificaion=0;
    const int longitudCalificacion=10;
    array <int,longitudCalificacion>Valoraciones={};
    for (int i=1;i<=20;i++){
        cout<<"Ingrese su valoracion: ";
        cin>>calificaion;
        Valoraciones[calificaion-1]++;
    }
    cout<<"Valoracion de la calidad ded la comida de la cafeteria\nValor\tFrecuencia"<<endl;
    for (int i=1;i<=longitudCalificacion;i++){
        cout<<i<<"\t"<<Valoraciones[i-1]<<endl;
    }
    //promedio
     cout<<"Ingrese la cantidad de alumnos: ";
    cin>>longitud;
    almacenarNotas(longitud);*/
    system("PAUSE");

    return 0;
}