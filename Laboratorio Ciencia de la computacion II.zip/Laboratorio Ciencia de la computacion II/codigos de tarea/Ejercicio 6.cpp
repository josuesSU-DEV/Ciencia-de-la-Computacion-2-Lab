#include <iostream>
#include<iomanip>
#include<array>
#include<math.h>
#include <ctime>
#include<algorithm>
#include<conio.h>
using namespace std; 
class Television{
    private:
        int resolucion=0;
        bool smartTv; 
        float precio;
    public:
        Television(int _resolucion,bool _smartTv,){
            resolucion=_resolucion;
            smartTv=_smartTv;
        }
        int  getResolucion(){
            return resolucion;
        }
        bool getSmartTv(){
            return smartTv;
        }
        void setPrecio(float _precioBase){
            precio=_precioBase;
        }
        float getPrecioBase(){
            return precio;
        }
        float PrecioFinal(){
            float precioXPulgada=getPrecioBase()/getResolucion();
            if(getResolucion()>40){
                precio+=(getResolucion()-40)*precioXPulgada/10;
            }
            if(getSmartTv()==true){
                precio+=100;
            }
            return precio;
        }   
        void mostrar(){
            cout<<"El TV comprado es tipo smart: "<<getSmartTv()<<"\nEl precio final es: "<<PrecioFinal();
        }     
};
/*class CuentaDeCredito:public Cuenta{
    //private:
        //float ingresar,retirar;
    public:
        CuentaDeCredito(string _titular):Cuenta( _titular){
        //titular=_titular;
        }
        void retirarCantidad(float retirar){
            if (retirar>getCantidad()){
                cout<<"No se puede retirar un monto que excede a su actual capacidad"<<endl;
            }
            else{
                retirarCantidad(retirar);
            }
        }
        void tasaDeInteres(float interes){
            agregarCantidad(getCantidad()*(interes/100));
        }
};*/
int main(){
    float precioBase;
    int resolucion;
    int opcion;
    bool smartTv;
    cout<<"----------------------------Ingresar valores--------------------------------"<<endl;
    cout<<"Ingrese el precio base: "<<endl;
    cin>>precioBase;
    cout<<"Ingrese la resolucion de la TV: "<<endl;
    cin>>resolucion;
    cout<<"1.Es Smart Tv\n2.No es Smart Tv: "<<endl;
    cin>>opcion;
    if (opcion==1){
        smartTv=true;
    }
    else{
        smartTv=false;
    }
    
    Television objeto(resolucion,smartTv);
    objeto.setPrecio(precioBase);
    objeto.PrecioFinal();
    objeto.mostrar();

    getch();
    return 0;
}