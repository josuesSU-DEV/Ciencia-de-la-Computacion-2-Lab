#include <iostream>
using namespace std;
int main(){
    int cantidad=1;
    int acumulador=0;
    int calificacion;
    cout<<cantidad<<".-Ingrese la calificacion: ";
    cin>>calificacion;
    while(calificacion !=-1){//centinela
        cout<<"------------------------------------------------------------------------------------------------"<<endl;
        acumulador+=calificacion;
        cout<<cantidad+1<<".-Ingrese la calificacion: ";
        cin>>calificacion;
        cantidad+=1;
    }
    cout<<"El promedio es "<<acumulador/(cantidad-1)<<endl;
    system("PAUSE"); 
    return 0;   
}