#include <iostream>
#include<iomanip>
#include<array>
#include<math.h>
#include <ctime>
#include<algorithm>
using namespace std;
//paso por referencia
void cuboPorReferencia(int *);

void suma(int a,int b, int *resultado);
void resta(int a,int b, int *resultado);
void multiplicacion(int a,int b, int *resultado);
void division(int a,int b, int *resultado);
void intercambiarPunteros(int** Ptr1,int** Ptr2);
int main(){
    int valor1=2000; 
    int valor2=3000;
    int* valor1Ptr=&valor1;
    int* valor2Ptr=&valor2;
    cout<<"Antes"<<endl;
    cout<<"Direccion Apuntada por el puntero 1 es "<<valor1Ptr<<endl;
    cout<<"Direccion Apuntada por el puntero 2 es "<<valor2Ptr<<endl;
    intercambiarPunteros(&valor1Ptr,&valor2Ptr);
    cout<<"Despues"<<endl;
    cout<<"Direccion Apuntada por el puntero 1 es "<<valor1Ptr<<endl;
    cout<<"Direccion Apuntada por el puntero 2 es "<<valor2Ptr<<endl;
    


    /*int a,b;
    int* aPtr=&a;
    int* bPtr=&b;
    int** bPtrPtr=&bPtr;*/
    /*int numero1;
    int numero2;
    int result=0;
    int opcion;
    cout<<"Ingrese Numero1: ";
    cin>>numero1;
    cout<<"Ingrese Numero2: ";
    cin>>numero2;
    cout<<"Ingrese Operacion: \n";
    cout<<"1.Suma\n2.Resta\n3.Multiplicacion\n4.Division\n5.Salir: ";
    cin>>opcion;
    while (true)
    {
        if(opcion==1){
            suma(numero1,numero2,&result);
        }
        if(opcion==2){
            resta(numero1,numero2,&result);
        }
        if(opcion==3){
            multiplicacion(numero1,numero2,&result);
        }
        if(opcion==4){
            division(numero1,numero2,&result);
        }
        else{
            break;
    }

    }
    
    
    /*cout<<"Ingrese el numero: ";
    cin>>a;
    cout<<"Ingrese el numero: ";
    cin>>b;
    cout<<"La direccion del puntero a es : "<<aPtr<<" y su valor almacenado es "<<*aPtr<<endl;
    cout<<"La direccion del puntero b es : "<<bPtr<<" y su valor almacenado es "<<*bPtr<<endl;
    //aPtr=bPtr;
    cout<<"La direccion del puntero a puntero es : "<<bPtrPtr<<" y su valor almacenado es "<<*bPtrPtr<<endl;*/
    //cout<<"La direccion del puntero b es : "<<bPtr<<" y su valor almacenado es "<<*bPtr<<endl;
    //cout<<"Que pasa si asignmos el valor del puntero b al puntero a "<<aPtr<<endl;
    system("PAUSE");
    return 0;
}
void cuboPorReferencia(int* numeroPtr){
    *numeroPtr=pow(*numeroPtr,3);
    
}
void suma(int a,int b, int* resultado){
    *resultado=a+b;
    cout<<"La suma es "<<*resultado<<endl;

}
void resta(int a,int b, int* resultado){
    *resultado=a-b;
    cout<<"La resta es "<<*resultado<<endl;
}
void multiplicacion(int a,int b, int* resultado){
    *resultado=a*b;
    cout<<"La multiplicacion es "<<*resultado<<endl;
}
void division(int a,int b, int* resultado){
    *resultado=a/b;
    cout<<"La division es "<<* resultado<<endl;
}
void intercambiarPunteros(int** Ptr1Ptr1,int** Ptr2Ptr2){
    int** PtrAuxiliar=Ptr1Ptr1;
    *Ptr1Ptr1=*Ptr2Ptr2;
    *Ptr2Ptr2=*PtrAuxiliar;
    
}