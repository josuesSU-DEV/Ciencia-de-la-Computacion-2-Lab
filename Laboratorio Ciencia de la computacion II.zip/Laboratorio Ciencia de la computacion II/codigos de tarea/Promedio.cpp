#include <iostream>
#include "Promedio.h"
using namespace std;
Promedio::Promedio(int promedio2){
    _promedio=promedio2;
}
int Promedio::getPromedio()const{
    return _promedio;
}
void Promedio::setPromedio(int promedio){
    _promedio=promedio;
}
void Promedio::promedioCentinela(){
    int cantidad=1;
    int acumulador=0;
    int calificacion;
    cout<<cantidad<<".-Ingrese la calificacion: ";
    cin>>calificacion;
    while(calificacion !=-1){
        cout<<"------------------------------------------------------------------------------------------------"<<endl;
        acumulador+=calificacion;
        cout<<cantidad+1<<".-Ingrese la calificacion: ";
        cin>>calificacion;
        cantidad+=1;
    }
    int promedio1=acumulador/(cantidad-1);
    setPromedio(promedio1);
    cout<<"El promedio es "<<getPromedio()<<endl;
    }