#include <iostream>
#include<iomanip>
#include<array>
#include<math.h>
#include <ctime>
#include<algorithm>
#include"Empleado1.cpp"
using namespace std;
int main(){
    string nombre,apellido;
    float salario;
    cout<<"Ingrese el nombre del empleado: ";
    getline(cin,nombre);
    cout<<"Ingrese el apellido del empleado: ";
    getline(cin,apellido);
     cout<<"Ingrese el salario del empleado: ";
    cin>>salario;
    Empleado1 Instancia(nombre,apellido,salario);
    cout<<"El nombre del empleado es "<<Instancia.getNombre()<<endl;
    cout<<"El apellido del empleado es "<<Instancia.getApellido()<<endl;
    cout<<"El salario es "<<Instancia.getSalario()<<endl;
    system("PAUSE");
    return 0;
}