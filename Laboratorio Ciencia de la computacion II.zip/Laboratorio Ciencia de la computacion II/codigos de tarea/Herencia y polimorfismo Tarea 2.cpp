#include <iostream>
#include<iomanip>
#include<array>
#include<math.h>
#include <ctime>
#include<algorithm>
#include<conio.h>
using namespace std; 
class Cuenta{
    private:
        float cantidad=0;
        string titular; 
    public:
        Cuenta(string _titular){
            titular=_titular;
            }
        Cuenta(){
            titular="Desconocido";
        }
        void setTitular(string _titular){
            titular=_titular;
        }
        string getTitular(){
            return titular;
        }
        float getCantidad(){
            return cantidad;
        }
        void agregarCantidad(float _cantidad){
            if (_cantidad>=0){
                cantidad+=_cantidad;
            }
            else{
                cout<<"No se puede agregar cantidad negativa"<<endl;
            }
        }
        virtual void retirarCantidad(float _cantidad){
            cantidad-=_cantidad;
        }
        void mostrar(){
            cout<<"El titular "<<getTitular()<<" tiene en su cuenta "<<getCantidad()<<" soles"<<endl;
        }
        //ejericio 3
};
class CuentaDeCredito:public Cuenta{
    //private:
        //float ingresar,retirar;
    public:
        CuentaDeCredito(string _titular):Cuenta( _titular){
        //titular=_titular;
        }
        void retirarCantidad(float retirar){
            if (retirar>getCantidad()){
                cout<<"No se puede retirar un monto que excede a su actual capacidad"<<endl;
            }
            else{
                retirarCantidad(retirar);
            }
        }
        void tasaDeInteres(float interes){
            agregarCantidad(getCantidad()*(interes/100));
        }
};
int main(){
    float agregarCantidad,quitarCantidad;
    string titular;
    cout<<"--------------------Cuenta----------------------"<<endl;
    cout<<"Ingrese el titular de la cuenta: ";
    cin>>titular;
    cout<<"Ingrese la cantidad a ingresar a la cuenta: ";
    cin>>agregarCantidad;
    cout<<"Ingrese la cantidad a retirar: ";
    cin>>quitarCantidad;
    Cuenta instancia(titular);
    instancia.agregarCantidad(agregarCantidad);
    instancia.retirarCantidad(quitarCantidad);
    instancia.mostrar();
    getch();
    return 0;
}