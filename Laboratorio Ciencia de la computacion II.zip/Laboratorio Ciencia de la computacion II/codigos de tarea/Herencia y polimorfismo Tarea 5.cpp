#include <iostream>
#include<iomanip>
#include<array>
#include<math.h>
#include <ctime>
#include<algorithm>
#include<conio.h>
using namespace std; 
//ejercicio 2
class Cuenta{
    private:
        float cantidad=0;
        string titular; 
    public:
        Cuenta(string _titular){
            titular=_titular;
            }
        Cuenta(){
            titular="Desconocido";
        }
        void setTitular(string _titular){
            titular=_titular;
        }
        string getTitular(){
            return titular;
        }
        float getCantidad(){
            return cantidad;
        }
        void agregarCantidad(float _cantidad){
            cantidad+=_cantidad;
        }
        void retirarCantidad(float _cantidad){
            cantidad-=_cantidad;
        }
        void mostrar(){
            cout<<"El titular "<<getTitular()<<" tiene en su cuenta "<<getCantidad()<<" soles"<<endl;
        }
};
int main(){
    float agregarCantidad,quitarCantidad;
    string titular;
    cout<<"--------------------Cuenta----------------------"<<endl;
    cout<<"Ingrese el titular de la cuenta: ";
    cin>>titular;
    cout<<"Ingrese la cantidad a ingresar a la cuenta: ";
    cin>>agregarCantidad;
    cout<<"Ingrese la cantidad a retirar: ";
    cin>>quitarCantidad;
    Cuenta instancia(titular);
    instancia.agregarCantidad(agregarCantidad);
    instancia.retirarCantidad(quitarCantidad);
    instancia.mostrar();
    getch();
    return 0;
}