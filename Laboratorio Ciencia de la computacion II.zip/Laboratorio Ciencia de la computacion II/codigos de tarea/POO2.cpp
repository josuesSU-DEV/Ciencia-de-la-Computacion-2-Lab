#include<iostream>
#include "Factura.cpp"
using namespace std;
int main(){
    string codigo,descripcion,codigo2,descripcion2;
    int cantidad,precio,cantidad2,precio2;
    cout<<"-------------------------------------------------------------------"<<endl;
    cout<<"Primer objeto"<<endl;
    cout<<"Ingrese el codigo: ";
    cin>>codigo;
    cout<<"Ingrese la descripcion: ";
    cin>>descripcion;
    cout<<"Ingrese la cantidad: ";
    cin>>cantidad;
    cout<<"Ingrese el precio: ";
    cin>>precio;
    Factura Instancia(codigo,descripcion,cantidad,precio);//Instancia del primer objeto
    Instancia.obtener();
    //Segundo objeto
    cout<<"-------------------------------------------------------------------"<<endl;
    cout<<"Segundo objeto"<<endl;
    cout<<"Ingrese el codigo: ";
    cin>>codigo2;
    cout<<"Ingrese la descripcion: ";
    cin>>descripcion2;
    cout<<"Ingrese la cantidad: ";
    cin>>cantidad2;
    cout<<"Ingrese el precio: ";
    cin>>precio2;
    Factura Instancia2(codigo2,descripcion2,cantidad2,precio2);//Instancia del primer objeto
    Instancia2.obtener();
    system("PAUSE");
    return 0;
}