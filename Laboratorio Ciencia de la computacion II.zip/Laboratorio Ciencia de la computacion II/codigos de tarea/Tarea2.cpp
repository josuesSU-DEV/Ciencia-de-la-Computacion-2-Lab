#include <iostream>
#include "math.h"
using namespace std;
int main()
{
    int a,b;
    cout<<"Hola bienvenido a la tarea 2 que es doblar el numero que ingreses";
    cout<<"Ingrese su primer numero: ";
    cin>>a;
    cout<<"Ingrese su segundo numero: ";
    cin>>b;
    cout<<pow(a,b)<<endl;
    system("PAUSE");
    return 0;

}