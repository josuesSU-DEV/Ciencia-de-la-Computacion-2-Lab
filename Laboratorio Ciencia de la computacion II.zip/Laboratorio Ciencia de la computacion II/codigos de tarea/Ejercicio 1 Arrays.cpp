#include <iostream>
#include<conio.h>
#include<stdlib.h>
using namespace std;
long long tamanio=1000000;
long long *arregloDin;
void llenarListaD(){
    arregloDin=new long long[tamanio];
    for(long long i=0;i<tamanio;arregloDin[i++]=i);
}
void llenarLista(long long arreglo[],long long size){
    for(long long i=0;i<size;arreglo[i++]=i);
}
void mostrarLista(long long arreglo[],long long tamanio){
    cout<<"Lista: "<<endl;
    for(long long i=0;i<tamanio;i++){
        cout<<arreglo[i]<<endl;
    }
}
long long sum(long long arreglo[],long long tamanio){//suma iterativa
    long long suma=0;
    for(long long i=0;i<tamanio;suma+=arreglo[i++]);
    return suma;
}
long long sumRec(long long arreglo[],long long tamanio){ //suma recursiva
    return tamanio==0?arreglo[0]:arreglo[tamanio]+sumRec(arreglo,tamanio-1);

}
int main(){
    llenarListaD();
    cout<<sum(arregloDin,tamanio);
    cout<<sumRec(arregloDin,tamanio-1);
    delete [] arregloDin;
    getch();
    return 0;  
}