#include <iostream>
#include "Factura.h"
using namespace std;
Factura::Factura(string codigoArticulo,string descripcion,int cantidad,int precio){
        if (cantidad>=0 && precio>=0){
            _codigoArticulo=codigoArticulo;
            _descripcion=descripcion;
            _cantidad=cantidad;
            _precio=precio;
        }
        else{
            _cantidad=0;
            _precio=0;
        }
    }
    string Factura::getCodigo(){
        return _codigoArticulo;
    }
    string Factura::getDescripcion(){
        return _descripcion;
    }
    int Factura::getCantidad(){
        return _cantidad;
    }
    int Factura::getPrecio(){
        return _precio;
    }
    void Factura::obtener(){
        cout<<"Factura\nCodigo\tDesc\tPrec\tCant\tTotal\n"<<getCodigo()<<"\t"<<getDescripcion()<<"\t"<<getPrecio()<<"\t"<<getCantidad()<<"\t"<<getPrecio()*getCantidad()<<endl;
    } 