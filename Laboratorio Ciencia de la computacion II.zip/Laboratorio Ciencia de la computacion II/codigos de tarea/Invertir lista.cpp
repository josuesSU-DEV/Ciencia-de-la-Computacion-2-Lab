#include <iostream>
using namespace std;
void ImprimirLista(int arreglo[],int cantidad){
    for (int i=0;i<cantidad;i++ ){
        cout<<arreglo[i]<<endl;
    }
}
void LlenarLista(int arreglo[],int cantidad){
    for (int i=0;i<cantidad;i++ ){
        cout<<"Ingrese el valor "<<endl;
        cin>>arreglo[i];
    }
}
void InvertirLista(int arreglo[],int cantidad){
    int aux;
    for(int i=0;i<cantidad/2;i++){
        aux=arreglo[i];
        arreglo[i]=arreglo[cantidad-1-i];
        arreglo[cantidad-1-i]=aux;
    }
}
using namespace std;

int main()
{
    const int largo=5;
    int arregloAux[4]={5,4,3,2};
    //LlenarLista(arregloAux,largo);
    InvertirLista(arregloAux,largo);
    ImprimirLista(arregloAux,largo);
    /*for(int i=0;i<4;i++)
        cout<<arregloAux[++i]<<" ";*/
    return 0;
}