#include <iostream>
#include <string>
#include "Empleado.cpp"
using namespace std;

int main(){
    string name,surname,name1,surname1;
    int salary,salary1;
    cout<<"-----------------------Primer empleado-----------------------------"<<endl;
    cout<<"A.-Ingrese el nombre del primer empleado: ";
    getline(cin,name);
    cout<<"B.-Ingrese el apellido del primer empleado: ";
    getline(cin,surname);
    cout<<"-----------------------Segundo empleado----------------------------"<<endl;
    cout<<"A.-Ingresar el nombre del segundo empleado: ";
    getline(cin,name1);
    cout<<"B.-Ingresar el apellido del segundo empleado: ";
    getline(cin,surname1);
    cout<<"-----------------------Primer empleado----------------------------"<<endl;
    cout<<"-Ingrese el salario mensual del primer empleado: ";
    cin>>salary;
    cout<<"-----------------------Segundo empleado----------------------------"<<endl;
    cout<<"-Ingrese el salario mensual del segundo empleado: ";
    cin>>salary1;
    Empleado Instancia(name,surname,salary);
    Instancia.salarioAnual();
    Empleado Instancia1(name1,surname1,salary1);
    Instancia1.salarioAnual();
    system("PAUSE");
    return 0;
}