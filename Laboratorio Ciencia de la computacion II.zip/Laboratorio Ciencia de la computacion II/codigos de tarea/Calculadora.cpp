#include<iostream>
#include<math.h>
#include "Calculadora.h"
using namespace std;
Calculadora::Calculadora(float num1,float num2){
    _num1=num1;
    _num2=num2;
}
float Calculadora::getNum1(){
    return _num1;
}
float Calculadora::getNum2(){
    return _num2;
}
string Calculadora::suma(){
    cout<<"La suma es: "<<getNum1()+getNum2()<<endl; 
}
string Calculadora::resta(){
    cout<<"La resta es: "<<getNum1()-getNum2()<<endl;
}
string Calculadora::multiplicacion(){
    cout<<"La multiplicacion es: "<<getNum1()*getNum2()<<endl;
}
string Calculadora::division(){
    cout<<"La division es: "<<getNum1()/getNum2()<<endl;
}
string Calculadora::potencia(){
    cout<<"La potencia es: "<<pow(getNum1(),getNum2())<<endl;
}