#include <iostream>
#include "LibroCalificacionesPromedio.h"
using namespace std;    
LibroCalificacionesPromedio::LibroCalificacionesPromedio(int calificacion1){
    _calificacion=calificacion1;
    cout<<"Bienvenido al programa"<<endl;
    }
int LibroCalificacionesPromedio::getCalificacion()const{
    return _calificacion;
}

void LibroCalificacionesPromedio::setCalificacionPromedio(int calificacion){
    _calificacion=calificacion;
}
int LibroCalificacionesPromedio::promedio(){
    int calificacion;
    int acumulador=0;
    int cantidad=0;
    cout<<".-Ingrese la calificacion: ";
    cin>>calificacion;


    while(calificacion !=-1){//centinela
        cout<<"------------------------------------------------------------------------------------------------"<<endl;
        acumulador+=calificacion;
        cout<<cantidad+1<<".-Ingrese la calificacion: ";
        cin>>calificacion;
        cantidad+=1;
        //cout<<"El numero de notas es "<<cantidad<<endl;
    }
    cout<<"El promedio es "<<acumulador/(cantidad-1)<<endl
}

/*int _acumulado;
        int _nroAlumnos;
        LibroCalificacionesPromedio(int nroAlumnos);
        int getCalificacion() const;
        void setCalificacion(int nroAlumnos1);
        int promedio();*/
