#include <iostream>
#include<iomanip>
#include<array>
#include<math.h>
#include <ctime>
#include<algorithm>
#include<string.h>
#include<sstream>
#include<conio.h>
using namespace std; 
//ejercicio 4
class Electrodomesticos{
    private:
        float precioBase=100,peso=5;
        string color="blanco";
        char consumoEnergetico='F'; 
    public:
        Electrodomesticos(){}
        Electrodomesticos(float _precioBase,float _peso){
            precioBase=_precioBase;
            peso=_peso;
        }
        Electrodomesticos(float _precioBase,float _peso,string _color,char _consumoEnergetico){
            precioBase=_precioBase;
            peso=_peso;
            color=_color;
            consumoEnergetico=_consumoEnergetico;
        }
        ~Electrodomesticos(){}
        float getPrecioBase(){
            return precioBase;
        }
        float getPeso(){
            return peso;
        }
        string getColor(){
            return color;
        }
        char getConsumoEnergetico(){
            return consumoEnergetico;
        }
        void setPrecioBase(float _precioBase){
            precioBase=_precioBase;
        }
        void setCambiarConsumo(char _consumo){
            consumoEnergetico=_consumo;
        }
        void setCambiarColor(string _color){
            color=_color;
        }
        void setComprobarConsumo(){
            char consumos[6]={'A','B','C','D','E','F'};
            size_t count=0;
            for (int i=0;i<6;i++){
                if (getConsumoEnergetico()==consumos[i]){
                    count+=1;
                }
            }
            if (count==0){
                cout<<"Consumo no encontrado retornara al consumo por defecto"<<endl;
                setCambiarConsumo('F');
            }
            else{
                cout<<"Consumo correcto"<<endl;
            }
        }
        void setComprobarColor(){
            string colores[5]={"blanco","negro","rojo","azul","gris"};
            size_t count=0;
            for (int i=0;i<5;i++){
                if (getColor()==colores[i]){
                    count+=1;
                }
            }
            if (count==0){
                cout<<"Color no encontrado retornara al color por defecto"<<endl;
                setCambiarColor("blanco");
            }
        }

        virtual void setPrecioFinal(){
            char consumos[6]={'A','B','C','D','E','F'};
            float extra[6]={50,70,90,100,120,150};
            for (int i=0;i<6;i++){
                if (getConsumoEnergetico()==consumos[i]){
                    precioBase+=extra[i];
                }
            }
        }
};
//ejercicio 5
class Lavadora:public Electrodomesticos{
    private:
        float carga;
    public:
    //float _precioBase,float _peso,string _color,char _consumoEnergetico
        Lavadora(float _precioBase,float _peso,string _color,char _consumoEnergetico,float _carga):Electrodomesticos(_precioBase,_peso,_color,_consumoEnergetico){
            carga=_carga;
        }
        ~Lavadora(){}
        void setPrecioFinal(){
            char consumos[6]={'A','B','C','D','E','F'};
            float extra[6]={50,70,90,100,120,150};
            for (int i=0;i<6;i++){
                if (getConsumoEnergetico()==consumos[i]){
                    setPrecioBase(getPrecioBase()+extra[i]);
                }
            }
            setPrecioBase(getPrecioBase()+carga*10);
        }
    };
void convertirMinsuculas(string &palabra){
    for(int i=0;i<palabra.length();i++){
        palabra[i]=tolower(palabra[i]);
    }
}
void convertirMayusculas(char &caracter){
    caracter=towupper(caracter);
}
int main(){
    float precioBase,peso;
    string color;
    char consumoEnergetico;
    float carga;
    float precioBase2,peso2;
    string color2;
    char consumoEnergetico2;
    float carga2;
    /*cout<<"--------------------------------Electrodomestico en general------------------------------------"<<endl;
    cout<<"Ingrese el precio base del electrodomestico: ";
    cin>>precioBase;
    cout<<"Ingrese el peso del electrodomestico: ";
    cin>>peso;
    cout<<"Ingrese el color del electrodomestico: ";
    cin>>color;
    convertirMinsuculas(color);
    cout<<"Ingrese el consumo energetico en terminos de A,B,C,D,E,F: ";
    cin>>consumoEnergetico;
    convertirMayusculas(consumoEnergetico);
    Electrodomesticos instancia(precioBase,peso,color,consumoEnergetico);
    cout<<"El color inicial es "<<instancia.getColor()<<endl;
    cout<<"El consumo inicial es "<<instancia.getConsumoEnergetico()<<endl;
    cout<<"El precio inicial es "<<instancia.getPrecioBase()<<endl;
    instancia.setComprobarColor();
    instancia.setComprobarConsumo();
    cout<<"El color comprobado es "<<instancia.getColor()<<endl;
    cout<<"El consumo comprobado es "<<instancia.getConsumoEnergetico()<<endl;
    instancia.setPrecioFinal();
    cout<<"El precio final es "<<instancia.getPrecioBase()<<endl;*/
    cout<<"--------------------------------Lavadora------------------------------------"<<endl;
    cout<<"Ingrese el precio base del electrodomestico: ";
    cin>>precioBase2;
    cout<<"Ingrese el peso del electrodomestico: ";
    cin>>peso2;
    cout<<"Ingrese el color del electrodomestico: ";
    cin>>color2;
    convertirMinsuculas(color2);
    cout<<"Ingrese el consumo energetico en terminos de A,B,C,D,E,F: ";
    cin>>consumoEnergetico2;
    convertirMayusculas(consumoEnergetico2);
    cout<<"Ingrese la carga que soporta la lavadora ";
    cin>>carga2;
    Lavadora instancia2(precioBase2,peso2,color2,consumoEnergetico2,carga2);
    instancia2.setPrecioFinal();
    cout<<"El precio final es "<<instancia2.getPrecioBase()<<endl;
    getch();
    return 0;
}