#include <iostream>
#include<string.h>
class Empleado1{
    private:
        std::string _nombre,_apellido;
        float _salario;
    public:
        Empleado1(std::string nombre,std::string apellido,float salario);
        void setNombre(std::string nombre);
        std::string getNombre();
        void setApellido(std::string apellido);
        std::string getApellido();
        void setSalario(float salario);
        float getSalario();
        float bono();
        float mostrarBono();
        float sueldoTotal();
    
};