#include <iostream>
#include"LibroCalificacionesPromedio.cpp"
using namespace std;
int main(){
    int alumnos,calificacion,acumulador;
    cout<<".-Ingrese el numero de estudiantes: ";
    cin>>alumnos;
    LibroCalificacionesPromedio InstanciaNotas(alumnos);
    acumulador=0;
    for (int i=1;i<=InstanciaNotas.getNroAlumnos();i++){
        cout<<".-Ingrese la calificacion: ";
        cin>>calificacion;
        acumulador+=calificacion;
    }
    cout<<"El promedio es "<<acumulador/(InstanciaNotas.getNroAlumnos())<<endl;
    system("PAUSE"); 
    return 0;   
}