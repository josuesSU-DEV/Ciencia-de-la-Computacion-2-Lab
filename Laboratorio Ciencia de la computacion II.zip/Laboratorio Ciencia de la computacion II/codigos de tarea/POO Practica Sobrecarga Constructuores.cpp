#include <iostream>
using namespace std;
class Fecha{
    private:
        int anio,mes,dia;
        int fecha;
    public:
        Fecha(int _anio,int _mes, int _dia){
            anio=_anio;
            mes=_mes;
            dia=_dia;
        }
        Fecha(int _fecha){
            int _dia,_mes,_anio;
            _dia=_fecha/1000000;
            _fecha%=1000000;
            _mes=_fecha/10000;
            _fecha%=10000;
            _anio=fecha;
        }
        /*void mostrar(){
            cout<<"La fecha es "<<
        }*/
};
class Figura{
    private: 
        string nombre;
    public:
        void mostrar();
}
class Cuadrado
int mani(){
    system("PAUSE");
    return 0;
}