#include <iostream>
#include <string>
class Promedio{
    private:
        int _promedio;
    public:
        Promedio(int promedio2);
        int getPromedio()const;
        void setPromedio(int promedio);
        void promedioCentinela();
};
