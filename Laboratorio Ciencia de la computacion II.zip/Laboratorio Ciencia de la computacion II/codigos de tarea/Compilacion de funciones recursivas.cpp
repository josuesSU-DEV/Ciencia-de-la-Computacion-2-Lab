#include<iostream>
#include "Recursividad.h"
using namespace std;
int fibonacci(int num1){
    if (num1==1){
        return 0;
    }
    else if (num1==2){
        return 1;
    }
    else{
        return fibonacci(num1-1)+fibonacci(num1-2);
    }
}
int factorial(int num1){
    if (num1==2){
        return 2;
    }
    else{
        return num1*factorial(num1-1);
        }
    } 

int MCD(int num1,int num2){
    if(num1==0){
        return num2;
    }
    else{
        return MCD(num2%num1,num1);
        }
}
int MCM(int num1,int num2){
    return (num1*num2)/MCD(num1,num2);
} 
int main(){
    int numero1,numero2;
    cout<<"Ingrese el numero de Fibonacci que quiere hallar ";
    cin>>numero1;
    cout<<"Ingrese el numero que quiere hallar el factorial ";
    cin>>numero2;
    cout<<"El numero de fibonacci "<<numero1<<" es "<<fibonacci(numero1)<<endl;
    cout<<"El numero factorial de "<<numero2<<" es "<<factorial(numero2)<<endl;
    cout<<"El MCM de "<<numero1<<" y "<<numero2<<" es "<<MCM(numero1,numero2)<<endl;
    cout<<"El MCD de "<<numero1<<" y "<<numero2<<" es "<<MCD(numero1,numero2)<<endl;
    system("PAUSE");
    return 0;
}