#ifndef _ESTUDIANTE_H_
#define _ESTUDIANTE_H_

#include <string>
class Curso {

    std::string nombre;
    int cui;
    int edad;
    char sexo;
    std::string semestre;
public:
    Estudiante();
    Estudiante(std::string, int, int, char, std::string);
    void setCui(int);
    int getCui();
    void setEdad(int);
    int getEdad();
    void setNombre(std::string);
    std::string getNombre();
    char getSexo();
    void setSexo(char);
    void setSemestre(std::string);
    std::string getSemestre();
};
Estudiante::Estudiante(){
    this->nombre = "";
    this->cui = 0;
    this->edad = 0;
    this->sexo = NULL;
    this->semestre = "";
}

Estudiante::Estudiante(std::string nombre, int cui, int edad, char sexo, std::string semestre){
    this->nombre = nombre;
    this->cui = cui;
    this->edad = edad;
    this->sexo = sexo;
    this->semestre = semestre;
}
//edad
int Estudiante::getEdad(){
    return edad;
}
void Estudiante::setEdad(int edad){
    this->edad=edad;
}
//cui
void Estudiante::setCui(int cui){
    this->cui=cui;
}
int Estudiante::getCui(){
    return cui;
}
//nombre
void Estudiante::setNombre(std::string nombre){
    this->nombre = nombre;
}
std::string Estudiante::getNombre(){
    return nombre;
}
//sexo
void Estudiante::setSexo(char sexo){
    this-> sexo= sexo;
}
char Estudiante::getSexo(){
    return sexo;
}
//Semestre
void Estudiante::setSemestre(std::string semestre){
    this->semestre=semestre;
}
std::string Estudiante::getSemestre(){
    return semestre;
}
#endif