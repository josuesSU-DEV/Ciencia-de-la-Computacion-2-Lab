#include <iostream>
#include <conio.h>
#include "DynamicArray.cpp"
#include"Curso.h"
#include"Point.h"
//ojo si no tienes el using namespace std y quieres sobrecargar el cout
//debes de poner un std::ostream
//en todos los ostream's que encuentres
using namespace std;

int main() {
    DynamicArray<Point> p;
    Point arr[4]={Point(5,4),Point(3,3),Point(7,6),Point(4,9) };
    int tam=sizeof(arr)/sizeof(arr[0]);
    DynamicArray<Point>q(arr,tam);
    cout<<q.getSize()<<endl;
    
    Point a(8,8);
    q.push_back(a);
   

    Curso c1("CVV",19,15,"abc");
    Curso c2("CC2",13,15,"def");
    Curso c3("TI",16,15,"ghi");
    Curso arreglo1[3]={c1,c2,c3};
    
    
    int tamanioArregloCurso=sizeof(arreglo1)/sizeof(arreglo1[0]);
    DynamicArray<Curso> arrayTemplateCurso(arreglo1,tamanioArregloCurso);

    cout<<"separando"<<endl;
    
    
    cout<<c1<<endl;
    cout<<arrayTemplateCurso;
    cout<<q;
    

    cout<<"si este es el archivo";
    getch();
   
    return 0;

}