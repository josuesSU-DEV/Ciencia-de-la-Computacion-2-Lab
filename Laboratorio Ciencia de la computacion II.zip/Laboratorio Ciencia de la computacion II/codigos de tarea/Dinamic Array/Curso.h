#include<string>
#include<iostream>

class Curso{
    private:
        std::string nombre;
        double notaFinal;
        int totalEstudiantes;
        std::string codigo;
    public:
        Curso(){
            this->nombre=" ";
            this->notaFinal=0;
            this->totalEstudiantes=0;
            this->codigo=" ";
        }
        Curso(std::string nombre,double notaFinal,int totalEstudiantes,std::string codigo){
            this->nombre=nombre;
            this->notaFinal=notaFinal;
            this->totalEstudiantes=totalEstudiantes;
            this->codigo=codigo;
        }
        void setNombre(std::string nombre){
            this->nombre=nombre;
        }
        void setNotaFinal(double notaFinal){
            this->notaFinal=notaFinal;
        }
        void setTotalEstudiantes(int totalEstudiantes){
            this->totalEstudiantes=totalEstudiantes;
        }
        void setCodigo(std::string codigo){
            this->codigo=codigo;
        }
        std::string getNombre()const{
            return this->nombre;
        }
        double getNotaFinal()const{
            return this->notaFinal;
        }
        int getTotalEstudiantes()const{
            return this->totalEstudiantes;
        }
        std::string getCodigo()const{
            return this->codigo;
        }
        friend std::ostream& operator <<(std::ostream &out,const Curso &obj){
            out<<"Curso: "<<obj.nombre<<std::endl<<"Nota final: "<<obj.notaFinal<<std::endl<<"Nro de Estudiantes: "<<obj.totalEstudiantes<<std::endl<<"Codigo del curso: "<<obj.codigo<<std::endl;
        }
};