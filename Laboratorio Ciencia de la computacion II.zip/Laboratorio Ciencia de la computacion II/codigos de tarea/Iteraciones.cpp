#include <iostream>
using namespace std;
void analisarNota(int nota){//Funcion que permitiraaa saaber si la anota es a
    if (nota>=0 && nota<=20){
        if (nota<10){
            cout<<"Desaprobado"<<endl;
        }
        else{
            cout<<"Aprobado"<<endl;
        }
    }
    else{
        cout<<"Nota ingresada invalida"<<endl;
    }
}
int main(){
    int a=1;
    int calificacion;
    while(a<=20){
        cout<<a<<".-Ingrese la calificacion: ";
        cin>>calificacion;
        analisarNota(calificacion);
        cout<<"------------------------------------------------------------------------------------------------"<<endl;
        a+=1;
    }
   system("PAUSE"); 
    return 0;   
}