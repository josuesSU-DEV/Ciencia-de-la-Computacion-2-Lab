//Clases y objetos
/*#include <iostream>
using namespace std;
class Curso{
    //datos miembro
    //funciones miembro
    private:
    string nombreCurso;//dato miembro es una variable que le pertenece a la clase Curso
    public:
    void asignarNombreCurso(string nombre){//las funciones empiezan con letras minusculas
        nombreCurso=nombre;
    }
    void mostrarCurso()const{
        cout<<"Bienvenidos al curso de programación de "<<nombreCurso;
    }
};
int main()
{
    string curso;
    cout<<"Ingrese el nombre del curso: ";
    //cin>>curso; solo almaCena una sola palabra sin contar espacios
    getline(cin,curso);
    Curso instanciaCurso;
    instanciaCurso.asignarNombreCurso(curso);
    instanciaCurso.mostrarCurso();
    return 0;
}*/
//Clases y objetos
//Clases y objetos
#include <iostream>
using namespace std;
class Calculadora{
    //datos miembro
    //funciones miembro
    //public:
    //private:
    //string _nombreUsuario;//dato miembro es una variable que le pertenece a la clase Curso
    int _numeroCuenta;
    public:
    void insertarNombre(string nombre){
        _nombreUsuario=nombre;
        
    }
    void insertarCuenta(int numero){
        _numeroCuenta=numero;
        
    }
    void saludar() {
        cout<<"Hola "<<_nombreUsuario<<" su cuenta esta registrada con el número: "<<string_numeroCuenta;
    }
};
int main()
{
    string persona;
    int cuenta;
    cout<<"Ingrese su nombre: ";
    //cin>>curso; solo almaCena una sola palabra sin contar espacios
    getline(cin,persona);
    cout<<"Ingrese su numero de cuenta: ";
    getline(cin,cuenta);
    CuentaBancaria usuario1;
    usuario1.insertarNombre(persona);
    usuario1.insertarCuenta(cuenta);
    usuario1.saludar();
    return 0;
}
//revisar el sgte codigo
/*#include <iostream>
using namespace std;
class Banco{
    //datos miembro
    //funciones miembro
    //public:
    private:
    string _nombreUsuario;//dato miembro es una variable que le pertenece a la clase Curso
    int _numeroCuenta;
    public:
    void insertarNombre(string nombre){
        _nombreUsuario=nombre;
        
    }
    void insertarCuenta(int numero){
        _numeroCuenta=numero;
        
    }
    void saludar() {
        cout<<"Hola "<<_nombreUsuario<<" su cuenta esta registrada con el número: ";
        cout<<_numeroCuenta;
    }
};
int main()
{
    string persona;
    int cuenta;
    cout<<"Ingrese su nombre: ";
    //cin>>curso; solo almaCena una sola palabra sin contar espacios
    getline(cin,persona);
    cout<<"Ingrese su numero de cuenta: ";
    getline(cin,cuenta);
    Banco user;
    user.insertarNombre(persona);
    user.insertarCuenta(cuenta);
    user.saludar();
    return 0;
}*/
// clase calculadora final
//clase 26 01 2020
#include <iostream>
using namespace std;
class LibroDeCalificaciones{
    public:
        LibroDeCalificaciones(string nombre){
            _nombreCurso=nombre;
        }
        void setNombreCurso(string nombre){
            _nombreCurso=nombre;
        }
        string getNombreCurso() const{
            return _nombreCurso;
        }
        void mostrarMensaje() const{
            cout<<"Bienvenido al curso de "<<getNombreCurso()<<" !";
        }
    private:
        string _nombreCurso();
};
int main()
{
    LibroDeCalificaciones libro1("Ciencias de la computacion");
    LibroDeCalificaciones libro2("Estructura de datos");
    cout<<libro1.getNombreCurso();
    cout<<libro2.getNombreCurso();
    return 0;
}
//clases
#include <iostream>
using namespace std ;
class LibroDeCalificaciones{
    public:
        LibroDeCalificaciones(string nombre){
            _nombreCurso=nombre;
        }
        void setNombreCurso(string nombre){
            _nombreCurso=nombre;
        }
        string getNombreCurso() const{
            return _nombreCurso;
        }
        void mostrarMensaje() const{
            cout<<"Bienvenido al curso de "<<getNombreCurso()<<" !";
        }
    private:
        string _nombreCurso;
};
int main()
{
    LibroDeCalificaciones libro1("Ciencias de la computacion");
    LibroDeCalificaciones libro2("Estructura de datos");
    cout<<libro1.getNombreCurso()<<"\n";
    cout<<libro2.getNombreCurso();
    return 0;
}