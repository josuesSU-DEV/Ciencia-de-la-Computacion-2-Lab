#include <iostream>
#include <conio.h>
using namespace std;
/*int quickSort(string cad){//Iterativa
    int sum=0;
    while(cad[sum]!= '\0'){
        sum+=1;
    }
    return sum;
}*/
int quicksortRec(){
    
}

int main()
{
    string aux="Hola mundo";//Tiene 10 caracteres incluyendo espacios
    cout<<"De forma iterativa la funcion nos cuenta que la cadena: "<<aux<<" tiene "<<contarCadena(aux)<<" caracteres"<<endl;
    cout<<"De forma recursiva la funcion nos cuenta que la cadena: "<<aux<<" tiene "<<contarCadenaRec(aux,0)<<" caracteres"<<endl;
    getch();
    return 0;
}