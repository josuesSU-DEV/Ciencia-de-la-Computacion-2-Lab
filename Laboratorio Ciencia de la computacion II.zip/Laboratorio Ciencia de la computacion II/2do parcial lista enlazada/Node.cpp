
#include "Node.h"
int Node::getValue()const{
    return this->value;
}
void Node::setValue(int value){
    this->value=value;
}
Node * Node::getNext()const{
    return this->next;
}
void Node::setNext(Node *next){
    this->next=next;
}

