#ifndef __LINKEDLIST_H__
#define __LINKEDLIST_H__
#include<iostream>
#include "Node.h"
class LinkedList{
    private:
        int size;
        Node *head;
    public:
        LinkedList();//constructor por defecto
        LinkedList(int);//insertando un "nodo" , pero en si insertamos un valor de tal nodo
        LinkedList(const LinkedList&);//constructor copia
        
        void insert(int);
        void removeByPosition(int);
        void removeByValue(int);
        
        bool search(int);
        /*friend std::ostream & operator <<(std::ostream &out,const LinkedList&obj){
            Node* actual=obj.head;//necesitamos siempre un auxiliar para hacer la iteracion desde la cabeza
            out<<"[ ";
            while(actual !=nullptr){
                out<<actual->getValue()<<" ";
                actual=actual->getNext();//esto nos sirve para que siga iterando

            }
            out<<" ]";
            return out;
        }*/
        friend std::ostream & operator <<(std::ostream & out,const LinkedList &lista);//declaramos el friend aca para poder acceder a sus datos miembro
        ~LinkedList();
};
#endif