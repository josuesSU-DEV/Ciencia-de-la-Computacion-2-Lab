#include"Node.cpp"
#include"LinkedList.h"

LinkedList::LinkedList(){//lista vacia
    this->size=0;//lista vacia
    this->head=nullptr;//apunta a un null porque la lista esta vacia
}

LinkedList::LinkedList(int value){
    this->size=1;//el tamaño se pone en 1 porque se le ingresa un "node" osea un valor
    this->head=new Node(value);
}

LinkedList::LinkedList(const LinkedList& o){
    this->size = 0;//tamaño 0- porque el aumento del size ya lo hace el insert
    this->head = nullptr;//la cabeza aun apunta a nullptr por lo q se sabe q la lista esta vacia
    Node* actual_o = o.head;//un auxiliar como siempre se iguala a la cabeza de la lista q queremos copiar
    while(actual_o!=nullptr)//mientras que el auxiliar siga recorriendo la lista
    {
        this->insert(actual_o->getValue());//se inserta un valor de la lista a copiar a la nueva lista
        actual_o = actual_o->getNext();//esta parte me permite recorrer la lista
    }

}
void LinkedList::insert(int value){
    Node *newNode = new Node(value);
    Node *tmp = head;
    if(head==nullptr){//si la lista esta vacia
        head = newNode;//se inserta despues de la cabeza
    } else {//si la lista no esta vacia
        if (head->getValue() > value) {//si aun el valor del nodo
            newNode->setNext(head);
            head = newNode;
        } else {
            while ( (tmp->getNext() != nullptr) && (tmp->getNext()->getValue() < value) )
            {
                tmp = tmp->getNext();
            }
            newNode->setNext(tmp->getNext());
            tmp->setNext(newNode);
        }
    }
    size++;
}
void LinkedList::removeByPosition(int posicion){
    if(posicion<size){
        Node *aux, *actual=head;
        if (posicion!=0){
            int i=0;
            while(i<posicion){
                aux = actual; actual = actual->getNext();
                i++;
            }
            aux -> setNext( actual->getNext() ); delete actual;
        }
        else{
            head = head -> getNext(); delete actual;
        }
        size--;
    }
}
void LinkedList::removeByValue(int value){
    Node *actual = head;//auxiliar para iterar entre nodos
    int position=0;//nos ayudara a controlar la posicion
    if(size != 0){//si la lista no esta vacia
        while (actual!=nullptr){//la 
            if (value == actual->getValue() ){
                removeByPosition(position); break;
            }
            position++; 
            actual = actual->getNext();
        }
    }
}

bool LinkedList::search(int value){
    Node *tmp = head;//auxiliar
    while(tmp != nullptr ){//mientras el puntero auxiliar no apunte a la cola no termina la lista
        if(tmp->getValue()==value){//si el puntero auxiliar que nos ayudo a recorrer encuentra retorna un valor de verdad
            return true;//si se encuentra retorna verdad
        }
        tmp = tmp->getNext();//este es como el incrementador o iterador si no se encuentra en la actual posicion
    }    
    return false;//si itero todo y no lo encontro retorna false
}
std::ostream &operator <<(std::ostream & out,const LinkedList &lista){//esta sobrecarga no necesita ser vinculado a la clase linkedList 
    Node *tmp=lista.head;
    out<<"[ ";
    while(tmp!=nullptr){
        out<<tmp->getValue()<<" ";
        tmp=tmp->getNext();
    }                      
    out<<" ]";                  
    return out;                        //es externa a dicha clase
}
LinkedList::~LinkedList(){
    Node *actual;
    while (this->head!=nullptr)
    {   
        actual=head->getNext();
        delete head;
        head=actual;
    }
    delete head;
    
}