#include<iostream>

class Estudiante{
    private:
        char * nombre;
        int edad;
    public:
        Estudiante(char *,int);
        Estudiante();

        Estudiante (const Estudiante &);
        Estudiante(Estudiante &&);
        Estudiante& operator=(const Estudiante &);
        Estudiante& operator=(Estudiante &&);
        char *getNombre()const;
        void setNombre(char *);
        int getEdad()const;
        void setEdad(int);

};
Estudiante::Estudiante(char *nombre,int edad){
    this->nombre=nombre;
    this->edad=edad;
}
Estudiante::Estudiante(){
    this->nombre=nullptr;
    this->edad=0;
}

Estudiante::Estudiante(const Estudiante &obj){//constructor copia
    this->nombre=obj.getNombre();
    this->edad=obj.getEdad();
}


Estudiante::Estudiante(Estudiante &&obj){//constructor de movimiento
    this->nombre=obj.getNombre();
    this->edad=obj.getEdad(); 
    obj.setNombre(nullptr);
    obj.setEdad(0);
}


Estudiante &Estudiante:: operator=(const Estudiante &obj){//asignacion de copia
    this->nombre=nullptr;
    this->nombre=obj.getNombre();
    this->edad=obj.getEdad();
    return *this;
    
}


Estudiante &Estudiante::operator=(Estudiante &&obj){//asignacion de movimiento
    this->nombre=nullptr;
    this->nombre=obj.getNombre();

    this->edad=obj.getEdad(); 
    
    obj.setNombre(nullptr);
    obj.setEdad(0);
    
    return *this;
}
char *Estudiante::getNombre()const{
    return this->nombre;
}
void Estudiante::setNombre(char *nombre){
    this->nombre=nombre;
}
int Estudiante::getEdad()const{
    return this->edad;
}
void Estudiante::setEdad(int edad){
    this->edad=edad;
}