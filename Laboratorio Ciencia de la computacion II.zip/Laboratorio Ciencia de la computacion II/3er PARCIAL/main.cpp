#include<iostream>
#include<conio.h>
#include<memory>
#include "Estudiante.h"
using namespace std;
int main() {
    
    
    shared_ptr<Estudiante>ptroEst1=make_shared<Estudiante>();//el puntero shared mediante el make_shared nos permite gestionar memoria dinamica lo que nos ayudara a crear un objeto dinamico Estudiante pasado por un constructor por defecto
    cout<<"Edad: "<<ptroEst1->getEdad()<<endl;
    unique_ptr<Estudiante>ptroEst2=make_unique<Estudiante>();//el puntero unique mediante el make_unique nos permite gestionar memoria dinamica lo que nos ayudara a crear un objeto dinamico Estudiante pasado por un constructor por defecto
    cout<<"Edad: "<<ptroEst2->getEdad()<<endl;
 
    weak_ptr<Estudiante>ptroEst3;//el puntero weak nos permite almacenar referencias de punteros shared , por lo cual almacenamos el objeto dinamico 1 en el que se uso un shared
    ptroEst3=ptroEst1;
    
    getch();
    return 0;
}
    
