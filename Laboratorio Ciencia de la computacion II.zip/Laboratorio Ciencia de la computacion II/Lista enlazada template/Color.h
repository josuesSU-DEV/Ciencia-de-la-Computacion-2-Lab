#include <iostream>
#include <conio.h>
class color
{
private:
    std::string name;
public:
    color();
    color(std::string);
    
    ~color();

    friend std::ostream& operator <<(std::ostream &salida1,const color& C){
        salida1<<C.name;
        return salida1;
    }
};

color::color()
{
    this->name="default";
}
color::color(std::string name){
    this->name=name;
}

color::~color()
{
}

