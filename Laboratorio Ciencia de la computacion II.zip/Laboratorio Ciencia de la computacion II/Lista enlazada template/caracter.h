#include<iostream>
class caracter
{
private:    
    char car;
public:
    caracter();
    caracter(char);
    
    caracter(const caracter&);
    
    ~caracter() ;
    friend std::ostream& operator <<(std::ostream &salida1,const caracter& C){
        salida1<<C.car;
        return salida1;
    }




};
caracter::caracter()
{
    this->car=' ';
}
caracter::caracter(char car)
{
    this->car=car;
}
caracter::caracter(const caracter&o){//constructor q copia un objeto Node * a un objeto iterator
    this->car=o.car;
}
caracter::~caracter()
{
}

