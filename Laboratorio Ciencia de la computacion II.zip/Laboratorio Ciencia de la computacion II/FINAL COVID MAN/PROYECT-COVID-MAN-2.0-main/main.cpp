#include <allegro.h>
#include "Mapa.cpp"


int main()
{
    allegro_init();//inicia la librer�a Allegro
    install_keyboard();//nos permite utilizar las teclas
    install_mouse();//parametros del mouse
    set_color_depth(32);
    int nivel=1;//Elegimos el nivel 1 del juego
    int ejeX=880;//Dimensiones de la ventana
    int ejeY=700;

    set_gfx_mode(GFX_AUTODETECT_WINDOWED,ejeX,ejeY,0,0);

 	if(install_sound(DIGI_AUTODETECT, MIDI_AUTODETECT, NULL) != 0){
       allegro_message("Error: inicializando sistema de sonido\n%s\n", allegro_error);
       return 1;
    }

    //control para el sonido, izq y der
	set_volume(200, 200);

    Mapa *noob=new Mapa(nivel,ejeX,ejeY);
    noob->setNivelMapa(1);
    noob->Mostrar();
    delete noob;

    return 0;
}
END_OF_MAIN();
