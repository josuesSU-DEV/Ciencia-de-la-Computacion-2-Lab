
class Obstaculos{
    private:
    public:
    virtual int getEjeX()=0;
    virtual int getEjeY()=0;
};
