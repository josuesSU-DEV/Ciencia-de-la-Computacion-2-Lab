#include "Node.cpp"
#include "LinkedList.h"

LinkedList::LinkedList() {
    this->size = 0;
    this->head = nullptr;
}

LinkedList::LinkedList(int value) {
    this->size = 1;
    this->head = new Node(value);
}

//Moises
LinkedList::LinkedList(const LinkedList &o) {
    this->size = 0;
    this->head = nullptr;
    Node* actual_o = o.head;
    while(actual_o!=nullptr)
    {
        this->insert(actual_o->getValue());
        actual_o = actual_o->getNext();
    }

}

// Merisabel
LinkedList::~LinkedList() {
    Node *actual;
    while (head!=nullptr){
        actual = head->getNext();
        delete head;
        head = actual;
    }
    delete head;
}

//Uberto
void LinkedList::insert(int value) {
    Node *newNode = new Node(value);//se crea el objeto dinámico o mejor conocido como NODO q se insertara
    Node *tmp = head;
    if(head==nullptr){
        head = newNode;
    } else {
        if (head->getValue() > value) {// si solo hay un elemento entre la cabeza y el nullptr
            newNode->setNext(head);
            head = newNode;
        } 
        else {
            while ( (tmp->getNext() != nullptr) && (tmp->getNext()->getValue() < value) )//si el temporal es decir si despues de la cabeza sigue habiendo nodos evaluaremos  
                                                                                         //si el valor de la derecha de nuestro nodo auxiliar tmp es menor al valor
                                                                                         //del nuevo nodo a insertar
                                                                                         //entonces sigue iterando
            {
                tmp = tmp->getNext();//la iteracion del tmp hacia adelante
                
            }
            newNode->setNext(tmp->getNext());//entonces al encontrar un nodo siguiente al tmp cuyo valor es mayor al valor del nodo a insertar entonces el 
                                             //el nuevo nodo apuntara a este mayor y el tmp apuntara a este nuevo nodo ya q por logica este es menor al nuevo nodo
                                             //a insertar
            
            tmp->setNext(newNode);//el nodo tmp ahora apuntara a el nuevo nodo reemplazando en posicion al q era menor a este nuevo nodo
        }
    }
    //delete tmp;
    size++;//aumentamos el tamaño
}

// Merisabel
void LinkedList::removeByPosition(int posicion) {
    if(posicion<size){
        Node *aux, *actual=head;
        if (posicion!=0){
            int i=0;
            while(i<posicion){
                aux = actual; 
                actual = actual->getNext();
                i++;
            }
            aux -> setNext( actual->getNext() ); 
            delete actual;
        }
        else{
            head = head -> getNext(); 
            delete actual;
        }
        size--;
    }
}


// Merisabel
void LinkedList::removeByValue(int value) {
    Node *actual = head;
    int position=0;
    if(size != 0){
        while (actual!=nullptr){
            if ( value == actual->getValue() ){
                removeByPosition(position); break;
            }
            position++; actual = actual->getNext();
        }
    }
}

//Ronald
bool LinkedList::search(int value) {    
    Node *tmp = head;
    
    while(tmp != nullptr ){
        if(tmp->getValue()==value){
            return true;
        }
        tmp = tmp->getNext();
    }    
    return false;
}

// Levi
// overload operator <<
std::ostream& operator <<(std::ostream &salida1,const LinkedList& C){
    Node* actual = C.head; 
    salida1 <<" [ ";
    while(actual!=nullptr){
        salida1 << actual->getValue()<<" ";
        actual = actual->getNext();
    }
    salida1 << "] ";
    return salida1;
}
