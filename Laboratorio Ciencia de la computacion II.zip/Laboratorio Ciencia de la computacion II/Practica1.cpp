#include <iostream>
using namespace std;
int main()
{
    int numero1,numero2,producto,promedio;// declaramos las variables que utilizaremos 
    cout<<"\nIngrese un numero : ";//imprimimos un mensaje en pantalla que pida ingresar uno de los numeros
    cin>>numero1;//se almacenara tal valor ingresado en la variable del primer numero anteriormente declarado
    cout<<"\nIngrese un numero : ";//imprimimos un mensaje en pantalla que pida ingresar uno de los numeros  
    cin>>numero2;//se almacenara tal valor ingresado en la variable del segundo numero anteriormente declarado
    producto=numero1*numero2;//El valor que almacenara la variable producto sera tal operacion de los numeros anteriormente declarados
    promedio=(numero1+numero2)/2;//El valor que almacenara la variable promedio sera tal operacion de los numeros anteriormente declarados
    cout<<"El producto es: "<<producto;//imprimimos en pantalla la variable producto
    cout<<"\nEl promedio es: "<<promedio;//imprimmimos en pantalla la variable promedio
    return 0;
}