struct Comida{
    BITMAP *comida=load_bitmap("Comida.bmp",NULL);
    int ejeX=30;//ancho de la imagen roca
    int ejeY=30;//alto de la imagen roca
};

