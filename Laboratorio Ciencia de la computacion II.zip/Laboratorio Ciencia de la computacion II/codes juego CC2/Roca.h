struct Casa{
    BITMAP *casa=load_bitmap("casita.bmp",NULL);//Variable de la imagen del muro;
    int ejeX=30;//ancho de la imagen roca
    int ejeY=30;//alto de la imagen roca
};

