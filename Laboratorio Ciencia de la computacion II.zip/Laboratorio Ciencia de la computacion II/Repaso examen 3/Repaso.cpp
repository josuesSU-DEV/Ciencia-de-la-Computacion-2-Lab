#include<iostream>
#include"conio.h"
using namespace std;
template<typename T>
T sumar(T dato1,T dato2){
    return dato1+dato2;
}
template<typename T>
T resta(T dato1,T dato2){
    return dato1-dato2;
}


int sumaInt(int num1,int num2){
    return num1+num2;
}
int restaInt(int num1,int num2){
    return num1-num2;
}
template<typename T>
T (*ptrFuncion)(T,T)=&sumar;
int(*ptrAmain)();
int main(){
    int(*puntero)(int,int)=&sumaInt;
    cout<<puntero(3,4)<<endl;
    puntero=&restaInt;
    cout<<puntero(5,2)<<endl;
    ptrAmain=&main;
    //cout<<ptrAmain()<<endl;
    
    cout<<ptrFuncion<int>(3,5)<<endl;
    getch();
    return 0;
}