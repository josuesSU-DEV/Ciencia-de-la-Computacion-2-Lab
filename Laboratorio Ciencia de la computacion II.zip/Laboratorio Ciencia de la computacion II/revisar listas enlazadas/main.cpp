#include <iostream>
#include "Node.h"
#include "LinkedList.h"


int main(){
	LinkedList<int> p;
	
    int opcion,dato;
    
	do{
		cout<<"\t.:MENU:.\n";
		cout<<"1. Insertar elementos a la lista\n";
		cout<<"2. Mostrar los elementos de la lista\n";
        cout<<"3. Eliminar un nodo de la lista\n";
		cout<<"4. Salir\n";
		cout<<"Opcion: ";
		cin>>opcion;
		
		switch(opcion){
			case 1: cout<<"\nDigite un numero: ";
					cin>>dato;
					p.insert(dato);
					cout<<"\n";
					system("pause");
					break;
			case 2: cout<<"Mostrando Lista\n";
					cout<<p<<'\n';
					system("pause");
					break;
			case 3: cout<<"\nDigite el elemento que desea eliminar: ";
					cin>>dato;
					p.remove(dato);
					cout<<"\n";
					system("pause");
					break;				
		}
		system("cls");
	}while(opcion != 4);

	return 0;
}