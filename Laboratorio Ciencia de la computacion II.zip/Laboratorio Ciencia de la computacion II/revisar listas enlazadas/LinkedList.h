#include <iostream>


template <class T>
class LinkedList{
	private:
		Node<T> *head;
	public:
		LinkedList(){
			this->head = NULL;
		}

		int insert(T dato){
			Node<T> *p = new Node<T>(), *q = NULL, *ant = NULL;
			if(!this->head or this->head->elem > dato){
				p->elem = dato;
				p->next = this->head;
				this->head = p;
			}
			else{
				q = this->head;
				while(q and q->elem < dato){
					ant = q;
					q = q->next;
				}
				p->elem = dato;
				ant->next = p;
				p->next = q;
			}
		}

		
		int remove(T dato){
			Node<T> *p, *ant = NULL;
			int resp = 1;
			if(this->head){
				p = this->head;
				while((p->next) and (p->elem != dato)){
					ant = p;
					p = p->next;
				}
				if(p->elem != dato){
					resp = 0;
				}
				else{
					if(this->head == p){
						this->head  = p->next;
					}
					else{
						ant->next = p->next;
					}
					delete (p);
				}
			}
			else{
				resp = -1;
			}
			return resp;
		}

		friend ostream& operator << <>(ostream &,const LinkedList<T> &);
};