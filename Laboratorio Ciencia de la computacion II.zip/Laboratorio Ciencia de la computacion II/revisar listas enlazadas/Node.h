#include <iostream>
using namespace std;

template <class T>
class LinkedList;

template <class T>
class Node;

template <class T>
ostream& operator<<(ostream &o, const LinkedList<T> &l){
    Node<T> *q = l.head;
	while(q){
		o<<q->elem<<' ';
		q = q->next;
	}
    return o;
}

template <class T>
class Node{
	private:
		Node<T> *next;
		T elem;
	public:
		Node(){
			this->next = NULL;
		}
		friend class LinkedList<T>;
		friend ostream& operator << <>(ostream &,const LinkedList<T> &);

};