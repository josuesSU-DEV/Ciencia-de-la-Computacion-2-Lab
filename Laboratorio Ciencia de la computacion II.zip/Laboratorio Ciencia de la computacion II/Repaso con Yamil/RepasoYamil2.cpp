#include <iostream>
using namespace std;
/*
template <int N>
class fact{
public:
    enum{val = N*fact<N-1>::val};
};

template <>
class fact<1>{
public:
    enum{val = 1};
};
*/
int funcion(int a){
    return a + 10;
}

template <int N>
class fact{
public:
    static int const var = N*fact<N-1>::var;
};

template <>
class fact<1>{
public:
    static int const var = 1;
};

constexpr int impr(int n){
    if(n == 1) return 1;
    return n*impr(n-1);
}

int main(){
    cout << fact<4>::var << '\n';
    cout << funcion(fact<4>::var) << '\n';
    return 0;
}