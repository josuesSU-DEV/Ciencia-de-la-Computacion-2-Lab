#include <bits/stdc++.h>
using namespace std;

int sumar(int a, int b){
    return a + b;
}

int restar(int a, int b){
    return a - b;
}

int operacion(int a, int b, int(*func)(int,int)){
    return func(a,b);
}

int main(){
    int c = operacion(1, 5, restar);
    cout << c << '\n';

    return 0;
}
