
#include <bits/stdc++.h>
using namespace std;

template <class T>
class Node{
private:
    T elem;
    shared_ptr<Node<T>> next;
public:
    Node(T elem){
        this->elem = elem;
        this->next = nullptr;
    }
    T getElem() const {
        return this->elem;
    }
    shared_ptr<Node<T>> getNext() const{
        return this->next;
    }
    void setNext(shared_ptr<Node<T>> next){
        this->next = next;
    }
};

template <class T>
class List{
private:
    int size;
    shared_ptr<Node<T>> head{nullptr};
public:
    List(){
        this->size = 0;
    }
    void insert(T elem){
        shared_ptr<Node<T>> p(new Node<T>(elem));
        if(this->head == nullptr){
            this->head = p;
        }
        else{
            shared_ptr<Node<T>> temp = this->head;
            while(temp->getNext()){
                temp = temp->getNext();
            }
            temp->setNext(p);
        }
        this->size++;
    }
    void print() const{
        shared_ptr<Node<T>> temp = this->head;
        while(temp){
            cout << temp->getElem() << ' ';
            temp = temp->getNext();
        }
        cout << '\n';
    }
};

int main(){
    List<int> myList;
    myList.insert(3);
    myList.insert(7);
    myList.insert(1);
    myList.insert(9);

    myList.print();
    
    return 0;
}
